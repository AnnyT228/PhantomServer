export class AssetsStateDto {
  SKIN?: string;
  CAPE?: string;
  HEAD?: string;
}
