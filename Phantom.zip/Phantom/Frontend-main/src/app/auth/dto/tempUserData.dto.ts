export class TempUserDataDto {
  usernameOrEmail?: string;
  password?: string;
  rememberMe?: boolean;
}
