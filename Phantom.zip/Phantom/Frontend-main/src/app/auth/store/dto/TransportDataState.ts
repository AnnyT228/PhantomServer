import {TempUserDataDto} from "@/app/auth/dto/tempUserData.dto";

export class TransportDataState  {
  public tempUserData: TempUserDataDto
}
