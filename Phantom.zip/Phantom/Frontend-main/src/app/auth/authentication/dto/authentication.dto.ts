export class AuthenticationDto {
  usernameOrEmail: string;
  password: string;
}
