export class RegistrationDto {
  username: string | null;
  email: string | null;
  password: string | null;
}
