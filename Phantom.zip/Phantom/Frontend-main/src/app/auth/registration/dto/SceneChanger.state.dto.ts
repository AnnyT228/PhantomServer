export class SceneChangerStateDto {
  currentIndex: number;
}
