import { AuthLogic } from './auth-logic';

describe('AuthLogic', () => {
  it('should create an instance', () => {
    expect(new AuthLogic()).toBeTruthy();
  });
});
