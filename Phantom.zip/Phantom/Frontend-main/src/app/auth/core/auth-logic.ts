import {NavigationLogic} from "@/app/auth/core/NavigationLogic";
import {AutoInsertion} from "@/app/auth/core/AutoInsertion";
import {FormControl} from "@angular/forms";
import {TempUserDataDto} from "@/app/auth/dto/tempUserData.dto";

export class AuthLogic {



}
