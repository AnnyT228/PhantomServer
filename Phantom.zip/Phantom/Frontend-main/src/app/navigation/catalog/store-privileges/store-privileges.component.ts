import { Component } from '@angular/core';

@Component({
  selector: 'app-store-privileges',
  templateUrl: './store-privileges.component.html',
  styleUrls: ['./store-privileges.component.scss']
})
export class StorePrivilegesComponent {

}
