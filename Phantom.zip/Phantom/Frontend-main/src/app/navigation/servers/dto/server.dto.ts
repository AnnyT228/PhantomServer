export class ServerDto {
  uniqueId: string;
  name: string;
  version: string;
  priority: number;
  description: string;
  icon: string | null;
}
