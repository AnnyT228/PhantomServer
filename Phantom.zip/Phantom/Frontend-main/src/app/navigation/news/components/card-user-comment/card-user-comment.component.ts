import { Component } from '@angular/core';

@Component({
  selector: 'app-card-user-comment',
  templateUrl: './card-user-comment.component.html',
  styleUrls: ['./card-user-comment.component.scss']
})
export class CardUserCommentComponent {

}
