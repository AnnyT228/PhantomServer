export type newsSortBy = "id:ASC" | "id:DESC" | "title:ASC" | "title:DESC" | "createdAt:ASC" | "createdAt:DESC"
