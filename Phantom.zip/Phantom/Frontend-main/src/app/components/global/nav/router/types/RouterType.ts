export type RouterType = {
  text: string,
  link: string,
  icon?: string | undefined,
  routerLinkActive?: string,
}
