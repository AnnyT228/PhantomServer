import { ImgfillDirective } from './imgfill.directive';

describe('ImgfillDirective', () => {
  it('should create an instance', () => {
    const directive = new ImgfillDirective();
    expect(directive).toBeTruthy();
  });
});
