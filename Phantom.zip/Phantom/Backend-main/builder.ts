import { BuildAction } from '@nestjs/cli/actions/build.action';
import { compileCode, compileFile } from 'bytenode';
import { build } from 'esbuild';
import { execSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const nestConfigPath = 'nest-cli.json'; // Regarding of the process.cwd
const nodeTarget = 'node20';
const distFolder = 'dist';
const entryFile = 'main.js'; // Regarding of the __dirname/distFolder
const bundleFile = 'bundle.js'; // Regarding of the __dirname/distFolder
const buildDir = 'build'; // Regarding of the __dirname
const buildFile = 'bundle.jsc'; // Regarding of the __dirname/distFolder
const packageJsonFile = 'package.json'; // Regarding of the __dirname
const loaderFile = 'loader.js';
const buildCommand = 'echo "No build required."';
const startCommand = `node ./${loaderFile}`;
const tarFile = 'release.tar.gz';
const clean = false; // instead of process.argv.includes('clean')

const log = (message: string, end = '\n\n'): boolean => process.stdout.write(`[Builder]: ${message}${end}`);

async function builder(): Promise<void> {
  const startTime = Date.now();

  log('Calling deployment services:');

  const nestEnd = logTime('Nest', `Compiling TypeScript from src/ to ${distFolder}/`, 'TypeScript is compiled');
  await nestEnd(new BuildAction().handle([{ name: 'app', value: 'app' }], [{ name: 'config', value: nestConfigPath }]));

  const esbuildEnd = logTime('ESBuild', `Bundling ${distFolder}/ to ${bundleFile}`, 'Bundle is created');
  await esbuildEnd(
    build({
      bundle: true,
      entryPoints: [resolve(__dirname, distFolder, entryFile)],
      platform: 'node',
      target: [nodeTarget],
      packages: 'external',
      minifySyntax: true,
      minifyWhitespace: true,
      outfile: resolve(__dirname, distFolder, bundleFile),
    }),
  );

  const buildDirPath = resolve(__dirname, buildDir);
  if (!existsSync(buildDirPath)) {
    log('Build directory is not created, creating.');
    mkdirSync(buildDirPath);
  } else {
    log('Build dir is already created, cleaning up.');
    rmSync(buildDirPath, { recursive: true, force: true });
    mkdirSync(buildDirPath);
  }

  const bytenodeEnd = logTime('Bytenode', `Compiling to bytecode in ${buildDir}/${buildFile}`, 'Bytecode is compiled');
  await bytenodeEnd(
    compileFile({
      filename: resolve(__dirname, distFolder, bundleFile),
      compress: true,
      output: resolve(__dirname, buildDir, buildFile),
      compileAsModule: true,
    }),
  );

  const yarnEnd = logTime(
    'Yarn',
    `Generating ${buildDir}/package.json from ./${packageJsonFile}`,
    'The package has been transfered',
  );
  const packageJson = JSON.parse(readFileSync(resolve(__dirname, packageJsonFile)).toString());

  process.stdout.write('[Yarn]: Transfering packages with fixed version:\n');
  process.stdout.write('[Yarn]: ');
  const dependencies: Record<string, string> = {};
  const promises: Promise<void>[] = [];
  for (const packageName of Object.keys(packageJson.dependencies)) {
    promises.push(
      (async () => {
        dependencies[packageName] = (await getPackageVersion(packageName)) ?? (packageJson.dependencies[packageName] as string);
        process.stdout.write(`${packageName}@${dependencies[packageName]} `);
      })(),
    );
  }
  await Promise.all(promises);
  process.stdout.write('\n');
  if (notInstalledPackages.length) process.stdout.write(`[Yarn]: Failed with packages: ${notInstalledPackages.join(' ')}`);

  const newPackageJson = {
    name: packageJson.name,
    author: packageJson.author,
    verstion: packageJson.version,
    license: packageJson.license,
    private: true,
    scripts: {
      build: buildCommand,
      start: startCommand,
    },
    dependencies,
  };
  writeFileSync(resolve(__dirname, buildDir, 'package.json'), JSON.stringify(newPackageJson, undefined, 2));
  yarnEnd('');

  log(`Writting loader ${buildDir}/${loaderFile}`);
  writeFileSync(resolve(__dirname, buildDir, loaderFile), loaderCode);

  const tarEnd = logTime('TarGZ', `Packing ${buildDir} into ./${tarFile}`, 'Build successfully packed to tar.gz');
  execSync(`tar -czf ../${tarFile} *`, { cwd: resolve(__dirname, buildDir) });
  tarEnd('');

  if (process.argv.includes('clean') || clean) {
    log('Cleaning...');
    rmSync('./dist', { force: true, recursive: true });
    rmSync('./build', { force: true, recursive: true });
  }

  log(`Builded successfully in ${((Date.now() - startTime) / 1000).toFixed(1)} seconds <3`);
}

function logTime(prefix: string, startMessage: string, endMessage: string): <T>(r: T) => T {
  const introTitle = `[ ${prefix} ]`;
  const introLength = 30 - introTitle.length;
  process.stdout.write(`${'_'.repeat(introLength / 2)}${introTitle}${'_'.repeat(introLength / 2)}\n`);

  process.stdout.write(`[${prefix}]: ${startMessage}...\n`);
  const startTime = Date.now();

  const resolve = (): void => {
    const elapsed = Date.now() - startTime;
    const elapsedSeconds = (elapsed / 1000).toFixed(2);
    process.stdout.write(`[${prefix}]: ${endMessage}. - ${elapsedSeconds}s\n\n`);
  };

  return <T>(returnData: T): T => {
    if (returnData instanceof Promise) returnData.then(resolve);
    else resolve();
    return returnData;
  };
}

let notInstalledPackages: string[] = [];
async function getPackageVersion(packageName: string): Promise<string | undefined> {
  let version: string | undefined = undefined;
  notInstalledPackages = [];

  try {
    const path = resolve(__dirname, 'node_modules', packageName, 'package.json');
    const file = await readFile(path).catch<false>(() => false);
    if (!file) notInstalledPackages.push(packageName);
    const packageJson = JSON.parse(file.toString());
    version = packageJson.version;
  } catch (_) {}

  if (!version) notInstalledPackages.push(packageName);
  return version;
}

const dummyBytecode = compileCode('', false);
const instruct = dummyBytecode.subarray(12, 16).toString('hex');

const loaderCode = [
  `// Generated by Pulse`,
  ``,
  `const { readFileSync } = require('node:fs');`,
  `const { brotliDecompressSync } = require('node:zlib');`,
  `const { Script, createContext } = require('node:vm');`,
  `const v8 = require('v8');`,
  ``,
  `v8.setFlagsFromString('--no-lazy');`,
  `v8.setFlagsFromString('--no-flush-bytecode');`,
  ``,
  `const instruct = '${instruct}';`,
  `const filename = '${buildFile}';`,
  ``,
  `const bytecodeBuffer = brotliDecompressSync(readFileSync(filename));`,
  `Buffer.from(instruct, 'hex').copy(bytecodeBuffer, 12)`,
  ``,
  `const substitutionLength = bytecodeBuffer.subarray(8, 12).reduce((sum, number, power) => sum += number * Math.pow(256, power), 0);`,
  `const substitutionCode = '\\u200b'.repeat(substitutionLength - 2);`,
  ``,
  `const script = new Script('"' + substitutionCode + '"', { cachedData: bytecodeBuffer });`,
  `const compiledWrapper = script.runInNewContext(createContext(global));`,
  ``,
  `compiledWrapper.call({}, {}, require, module, filename, __dirname);`,
  ``,
].join('\n');

builder();
