export namespace Exceptions {
  export enum UsersExceptions {
    UserExist = 'UserExist',
    UserNotFound = 'UserNotFound',
    WrongPassword = 'WrongPassword',
  }

  export enum PermissionsExceptions {
    ApiKeyNotFound = 'ApiKeyNotFound',
    ApiKeyNoSuchPermissions = 'ApiKeyNoSuchPermissions',
  }

  export enum TokensExceptions {
    JwtTokenNotFound = 'JwtTokenNotFound',
    JwtTokenExpired = 'JwtTokenExpired',
    JwtTokenMalformed = 'JwtTokenMalformed',
  }

  export enum LinksExceptions {
    ActivationLinkExpired = 'ActivationLinkExpired',
    PasswordResetLinkExpired = 'PasswordResetLinkExpired',
  }

  export enum ValidationExceptions {
    WrongDto = 'WrongDto',
    BadFile = 'BadFile',
  }

  export enum OtherExceptions {
    Unhandled = 'Unhandled',
    MissingRequiredFile = 'MissingRequiredFile',
    MissingRequiredCookie = 'MissingRequiredCookie',
  }

  export enum GravitExceptions {
    UserNotFound = 'auth.usernotfound',
    WrongPassword = 'auth.wrongpassword',
    UserBanned = 'auth.userblocked',
    TokenExpire = 'auth.expiretoken',
    InvalidToken = 'auth.invalidtoken',
  }
}
