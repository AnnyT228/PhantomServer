import { HttpStatus } from '@nestjs/common';
import { Exceptions } from '@common/api-exceptions/exceptions.namespace';

type CustomExceptions = typeof Exceptions & {
  HttpExceptions: string;
};

type ExceptionType<T extends keyof CustomExceptions> = CustomExceptions[T];
type ExceptionReason<T extends keyof CustomExceptions> =
  ExceptionType<T>[keyof ExceptionType<T>];

interface IApiExceptionError<T extends keyof CustomExceptions> {
  type: T;
  reason: ExceptionReason<T>;
  validationErrors?: string[];
}

export class ApiException<T extends keyof CustomExceptions> {
  public statusCode: HttpStatus;
  public error: IApiExceptionError<T>;

  constructor(
    statusCode: HttpStatus,
    type: T,
    reason: ExceptionReason<T>,
    validationErrors?: T extends 'ValidationExceptions' ? string[] : undefined,
  ) {
    this.statusCode = statusCode;
    this.error = { type, reason };

    if (validationErrors) this.error.validationErrors = validationErrors;
  }
}

// Usage example

// new ApiException(
//   HttpStatus.NOT_FOUND,
//   'UserExceptions',
//   Exceptions.UserExceptions.UserNotFound,
// );
// OR
// new ApiException<'UserExceptions'>(
//   HttpStatus.NOT_FOUND,
//   'UserExceptions',
//   Exceptions.UserExceptions.UserNotFound,
// );

// Output example

// {
//   statusCode: 404,
//   error: { type: 'UserExceptions', reason: 'UserNotFound' }
// }
