import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  Logger,
  WsExceptionFilter,
} from '@nestjs/common';
import { Response } from 'express';
import { Socket } from 'socket.io';
import { ApiException } from '@common/api-exceptions/api-exception.error';
import { Exceptions } from '@common/api-exceptions/exceptions.namespace';

@Catch()
export class ApiExceptionHandler implements ExceptionFilter, WsExceptionFilter {
  private readonly logger = new Logger('Exception');
  private lastErrorTime: number;
  private cachedErrorMessage: string;

  constructor() {
    process.on('uncaughtException', (e) => this.unhandledErrorHandler(e));
    process.on('unhandledRejection', (e) =>
      this.unhandledErrorHandler(e as Error),
    );
  }

  private unhandledErrorHandler(error: Error): void {
    const lastErrorDate = Date.now();

    if (
      this.lastErrorTime &&
      lastErrorDate - this.lastErrorTime < 200 &&
      error.message === this.cachedErrorMessage
    ) {
      return;
    }

    this.lastErrorTime = lastErrorDate;
    this.cachedErrorMessage = error.message;

    this.logger.error(
      `${error.message}${error.stack ? `\n${error.stack}` : ''}`,
    );
  }

  catch(exception: unknown, host: ArgumentsHost): any {
    const context = host.switchToHttp();
    const response = context.getResponse<Response>();

    const client = host.switchToWs().getClient<Socket>();

    const statusCode =
      exception instanceof ApiException
        ? exception.statusCode
        : exception instanceof HttpException
        ? exception.getStatus()
        : HttpStatus.INTERNAL_SERVER_ERROR;

    function getErrorFromHttpException(): ApiException<'HttpExceptions'> {
      const httpException = (exception as HttpException).getResponse() as {
        statusCode: number;
        message: string;
        response: string;
      };

      return new ApiException(
        httpException.statusCode ?? statusCode,
        'HttpExceptions',
        httpException.message,
      );
    }

    const message =
      exception instanceof HttpException
        ? getErrorFromHttpException()
        : exception instanceof ApiException
        ? exception
        : new ApiException(
            HttpStatus.INTERNAL_SERVER_ERROR,
            'OtherExceptions',
            Exceptions.OtherExceptions.Unhandled,
          );

    if (client.connected) {
      client.emit('exception', message);
      return void client.disconnect(true);
    }

    response
      .setHeader('Content-Type', 'application/json')
      .status(statusCode)
      .send(message);

    if (
      !(exception instanceof ApiException) &&
      !(exception instanceof HttpException)
    ) {
      this.logger.error(exception);
    }
  }
}
