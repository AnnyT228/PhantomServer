import { Type } from '@nestjs/common/interfaces';
import {
  ExecutionContext,
  ParamData,
  ParamDecoratorEnhancer,
  PipeTransform,
} from '@nestjs/common';
import { ROUTE_ARGS_METADATA } from '@nestjs/common/constants';
import { assignCustomParameterMetadata } from '@nestjs/common/utils/assign-custom-metadata.util';
import { uid } from 'uid';

type ParamDecorator = (
  ...pipes: (Type<PipeTransform> | PipeTransform)[]
) => ParameterDecorator;

type ParamDecoratorWithData<FactoryData> = (
  data: FactoryData,
  ...pipes: (Type<PipeTransform> | PipeTransform)[]
) => ParameterDecorator;

type CustomParamFactory<TInput = any, TOutput = any> = (
  input: TInput,
) => TOutput;

type CustomParamFactoryWithData<TData = any, TInput = any, TOutput = any> = (
  input: TInput,
  data: TData,
) => TOutput;

export function createAdvancedParamDecorator<
  FactoryInput extends ExecutionContext = any,
  FactoryOutput = any,
>(
  factory: CustomParamFactory<FactoryInput, FactoryOutput>,
  enhancers?: ParamDecoratorEnhancer[],
): ParamDecorator;

export function createAdvancedParamDecorator<
  FactoryData extends ParamData = any,
  FactoryInput extends ExecutionContext = any,
  FactoryOutput = any,
>(
  factory: CustomParamFactoryWithData<FactoryData, FactoryInput, FactoryOutput>,
  enhancers?: ParamDecoratorEnhancer[],
): ParamDecoratorWithData<FactoryData>;

export function createAdvancedParamDecorator<
  FactoryData extends ParamData = any,
  FactoryInput extends ExecutionContext = any,
  FactoryOutput = any,
>(
  factory: CustomParamFactoryWithData<FactoryData, FactoryInput, FactoryOutput>,
  enhancers: ParamDecoratorEnhancer[] = [],
): ParamDecorator | ParamDecoratorWithData<FactoryData> {
  return processDecoratorMetadata(factory, enhancers);
}

function processDecoratorMetadata(
  factory: CustomParamFactory | CustomParamFactoryWithData,
  enhancers: ParamDecoratorEnhancer[],
) {
  return function <FactoryData>(
    data: FactoryData,
    ...pipes: (Type<PipeTransform> | PipeTransform)[]
  ): ParameterDecorator {
    return (target, key, index) => {
      const argsMetadata =
        Reflect.getMetadata(ROUTE_ARGS_METADATA, target.constructor, key) || {};

      const isPipe = (pipe: any): boolean =>
        pipe &&
        ((typeof pipe === 'function' &&
          pipe.prototype &&
          typeof pipe.prototype.transform === 'function') ||
          typeof pipe.transform === 'function');

      const hasParamData = !data || !isPipe(data);
      const paramData = hasParamData ? (data as ParamData) : undefined;
      const paramPipes = hasParamData ? pipes : [data, ...pipes];

      const swappedFactory = (
        data: unknown,
        ctx: ExecutionContext,
      ): ReturnType<typeof swappedFactory> => factory(ctx, data);

      Reflect.defineMetadata(
        ROUTE_ARGS_METADATA,
        assignCustomParameterMetadata(
          argsMetadata,
          uid(16),
          index,
          swappedFactory,
          paramData,
          ...(paramPipes as PipeTransform[]),
        ),
        target.constructor,
        key,
      );

      enhancers.forEach((fn) => fn(target, key, index));
    };
  };
}
