import { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';
import { FileInterceptor } from '@nestjs/platform-express';
import { memoryStorage } from 'multer';

export class FileHandler implements NestInterceptor {
  constructor(private readonly fieldName: string = 'file') {}

  intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Observable<any> | Promise<Observable<any>> {
    const fileInterceptor = FileInterceptor(this.fieldName, {
      storage: memoryStorage(),
    });

    return new fileInterceptor().intercept(context, next);
  }
}
