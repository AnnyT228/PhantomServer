import { ExecutionContext, HttpStatus } from '@nestjs/common';
import { Request } from 'express';
import { ApiException } from '@common/api-exceptions/api-exception.error';
import { createAdvancedParamDecorator } from '@common/other/create-advanced-param-decorator';
import { Exceptions } from '@common/api-exceptions/exceptions.namespace';

export const Cookies = createAdvancedParamDecorator(
  (ctx: ExecutionContext, data: string) => {
    const request = ctx.switchToHttp().getRequest<Request>();

    const cookie = request.cookies?.[data] || request.signedCookies?.[data];

    if (!cookie) {
      throw new ApiException(
        HttpStatus.BAD_REQUEST,
        'OtherExceptions',
        Exceptions.OtherExceptions.MissingRequiredCookie,
      );
    }

    return cookie;
  },
);
