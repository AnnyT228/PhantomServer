import { CookieOptions } from 'express';
import { envConfig } from '@common/configs/env.config';

export const refreshCookiesSettings: Readonly<CookieOptions> = {
  maxAge: 60 * 60 * 24 * 31 * 1000,
  httpOnly: true,
  signed: true,
  secure: envConfig.api.url.protocol === 'https:',
  sameSite: true,
};
