import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { INestApplication } from '@nestjs/common';
import { envConfig } from '@common/configs/env.config';

export function setupSwagger(swaggerConfig: {
  app: INestApplication;
  path: string;
  enabled: boolean;
}): void {
  if (!swaggerConfig.enabled) return;

  const config = new DocumentBuilder()
    .addServer(envConfig.api.url.href)
    .setTitle('Phantom API')
    .setDescription('Phantom API documentation')
    .setVersion('1.0.0')
    .build();
  const document = SwaggerModule.createDocument(swaggerConfig.app, config);

  SwaggerModule.setup(swaggerConfig.path, swaggerConfig.app, document);
}
