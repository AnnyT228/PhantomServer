import {
  DeepPartial,
  FindManyOptions,
  FindOneOptions,
  FindOptionsWhere,
  Repository,
} from 'typeorm';
import { NotFoundException } from '@nestjs/common';
import { Type } from '@nestjs/common/interfaces';

type ExtractTypeOrNever<T, K> = T extends undefined ? never : K;

export abstract class BaseEntityService<
  Entity extends object,
  EntityDto = undefined,
> {
  protected constructor(entityRepository: Repository<Entity>);
  protected constructor(
    entityRepository: Repository<Entity>,
    entityDto: ExtractTypeOrNever<EntityDto, Type<EntityDto>>,
  );
  protected constructor(
    private readonly entityRepository: Repository<Entity>,
    private readonly entityDto: ExtractTypeOrNever<
      EntityDto,
      Type<EntityDto>
    > = undefined,
  ) {}

  private isEntity(
    entity: unknown,
    checkBy: FindOptionsWhere<Entity>,
  ): entity is Entity {
    if (!checkBy) return true;

    return Object.keys(checkBy).some(
      (entityProperty) => !!(entity as Entity)[entityProperty],
    );
  }

  async findOneBy(options: FindOneOptions<Entity>): Promise<Entity>;
  async findOneBy(
    options: FindOneOptions<Entity>,
    convertToDto: ExtractTypeOrNever<EntityDto, true>,
  ): Promise<ExtractTypeOrNever<EntityDto, EntityDto>>;
  async findOneBy(
    options: FindOneOptions<Entity>,
    convertToDto?: ExtractTypeOrNever<EntityDto, boolean>,
  ): Promise<Entity | EntityDto> {
    const existEntity = await this.entityRepository.findOne(options);

    if (!existEntity) throw new NotFoundException();

    if (convertToDto) return new this.entityDto(existEntity);

    return existEntity;
  }

  async findManyBy(options: FindManyOptions<Entity>): Promise<Entity[]>;
  async findManyBy(
    options: FindManyOptions<Entity>,
    convertToDto: ExtractTypeOrNever<EntityDto, true>,
  ): Promise<ExtractTypeOrNever<EntityDto, EntityDto[]>>;
  async findManyBy(
    options: FindManyOptions<Entity>,
    convertToDto?: ExtractTypeOrNever<EntityDto, boolean>,
  ): Promise<Entity[] | EntityDto[]> {
    const existEntities = await this.entityRepository.find(options);

    if (!existEntities.length) throw new NotFoundException();

    if (convertToDto) {
      return existEntities.map((entity) => new this.entityDto(entity));
    }

    return existEntities;
  }

  async updateOneBy<T extends keyof Entity>(
    optionsOrEntity: FindOneOptions<Entity> | Entity,
    update: Partial<Record<T, Entity[T]>>,
  ): Promise<void> {
    const entity = this.isEntity(optionsOrEntity, optionsOrEntity['where'])
      ? optionsOrEntity
      : await this.findOneBy(optionsOrEntity);

    const updatedEntity: Entity = this.entityRepository.merge(
      entity,
      update as DeepPartial<Entity>,
    );

    await this.entityRepository.save(updatedEntity);
  }

  async removeOneBy(
    optionsOrEntity: FindOneOptions<Entity> | Entity,
  ): Promise<void> {
    const entity = this.isEntity(optionsOrEntity, optionsOrEntity['where'])
      ? optionsOrEntity
      : await this.findOneBy(optionsOrEntity);

    await this.entityRepository.remove(entity);
  }

  async removeManyBy(
    optionsOrEntity: FindManyOptions<Entity> | Entity[],
  ): Promise<void> {
    const entities = Array.isArray(optionsOrEntity)
      ? optionsOrEntity
      : await this.findManyBy(optionsOrEntity);

    await this.entityRepository.remove(entities);
  }
}
