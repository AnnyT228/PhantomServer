import {
  ArgumentMetadata,
  HttpStatus,
  Injectable,
  PipeTransform,
} from '@nestjs/common';
import { ApiException } from '@common/api-exceptions/api-exception.error';
import { StorageService } from '@/core/storage/storage.service';
import { MemoryStorageFile } from '@/core/storage/types/memory-storage-file.type';
import { Exceptions } from '@common/api-exceptions/exceptions.namespace';

@Injectable()
export class FileValidationPipe implements PipeTransform {
  private errors: string[];

  constructor(
    private readonly options?: {
      filesIsRequired?: boolean;
      maxSizeInMiB?: number;
    },
  ) {
    this.options.filesIsRequired = this.options.filesIsRequired ?? true;
    this.options.maxSizeInMiB = this.options.maxSizeInMiB ?? 1;
  }

  transform(
    fileOrFiles: MemoryStorageFile | MemoryStorageFile[],
    metadata: ArgumentMetadata,
  ): MemoryStorageFile | MemoryStorageFile[] {
    if (!fileOrFiles && !this.options.filesIsRequired) {
      return;
    }

    this.errors = [];

    if (Array.isArray(fileOrFiles)) {
      fileOrFiles.forEach((file) => this.checkFile(file));
    } else {
      this.checkFile(fileOrFiles);
    }

    if (this.errors.length > 0) {
      throw new ApiException(
        HttpStatus.BAD_REQUEST,
        'ValidationExceptions',
        Exceptions.ValidationExceptions.BadFile,
        this.errors,
      );
    }

    return fileOrFiles;
  }

  private isFile(file: unknown): file is MemoryStorageFile {
    return !!(file as MemoryStorageFile)?.buffer;
  }

  private checkFile(file: MemoryStorageFile): void {
    if (!this.isFile(file)) {
      return void this.errors.push(`The file was not provided.`);
    }

    if (!StorageService.getInstance.getFileMimeType(file.buffer)) {
      this.errors.push(
        `This file is not a ${file.mimetype.split('/')[1]} image.`,
      );
    }

    if (file.size > this.options.maxSizeInMiB * 1024 * 1024) {
      this.errors.push(
        `The file size is more than ${this.options.maxSizeInMiB} MiB`,
      );
    }
  }
}
