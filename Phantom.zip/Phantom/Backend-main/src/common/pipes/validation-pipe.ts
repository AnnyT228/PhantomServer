import { HttpStatus, ValidationError, ValidationPipe } from '@nestjs/common';
import { ApiException } from '@common/api-exceptions/api-exception.error';
import { Exceptions } from '@common/api-exceptions/exceptions.namespace';

export const CustomValidationPipe = new ValidationPipe({
  transform: true,
  whitelist: true,
  forbidNonWhitelisted: true,
  exceptionFactory(validationErrors: ValidationError[]) {
    const errors: string[] = [];

    validationErrors?.forEach((error) => {
      if (error.constraints) errors.push(...Object.values(error.constraints));

      error.children?.forEach((error) => {
        if (error.constraints) errors.push(...Object.values(error.constraints));
      });
    });

    throw new ApiException(
      HttpStatus.BAD_REQUEST,
      'ValidationExceptions',
      Exceptions.ValidationExceptions.WrongDto,
      errors,
    );
  },
});
