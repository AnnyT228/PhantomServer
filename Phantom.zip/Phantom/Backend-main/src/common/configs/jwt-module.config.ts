import { JwtModuleOptions } from '@nestjs/jwt';
import { envConfig } from '@common/configs/env.config';

export const jwtModuleConfig: Readonly<JwtModuleOptions> = {
  secret: envConfig.secure.jwt.secret,
  signOptions: {
    algorithm: 'HS256',
  },
  verifyOptions: {
    algorithms: ['HS256'],
  },
  global: true,
};
