import { ThrottlerOptions } from '@nestjs/throttler';
import { envConfig } from '@common/configs/env.config';

export const throttlerModuleConfig: Readonly<ThrottlerOptions> = {
  ttl: envConfig.throttler.ttl,
  limit: envConfig.throttler.limit,
};
