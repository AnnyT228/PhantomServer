import { from } from 'env-var';
import { config } from 'dotenv';
import { resolve } from 'path';
import * as process from 'process';

const env = from(process.env);
config({ path: resolve(process.cwd(), '.env') });

export const envConfig = {
  api: {
    url: env.get('API_URL').required().asUrlObject(),
    port: env.get('API_PORT').required().asPortNumber(),
    frontendUrl: env.get('FRONTEND_URL').required().asUrlObject(),
    sitename: env.get('SITENAME').required().asString(),
  },

  throttler: {
    ttl: env.get('THROTTLER_TTL').default(1).asIntPositive(),
    limit: env.get('THROTTLER_LIMIT').default(10).asIntPositive(),
  },

  swagger: {
    enabled: env.get('SWAGGER_ENABLED').default(0).asBool(),
    path: env.get('SWAGGER_PATH').asUrlObject(),
  },

  redis: {
    host: env.get('REDIS_HOST').required().asString(),
    port: env.get('REDIS_PORT').required().asPortNumber(),
    username: env.get('REDIS_USERNAME').asString(),
    password: env.get('REDIS_PASSWORD').asString(),
    clientName: env.get('REDIS_CLIENT_NAME').asString(),
    databaseIndex: env.get('REDIS_DB_INDEX').required().asInt(),
    keyPrefix: env.get('REDIS_KEY_PREFIX').required().asString(),
  },

  database: {
    host: env.get('DB_HOST').required().asString(),
    port: env.get('DB_PORT').required().asPortNumber(),
    user: env.get('DB_USER').required().asString(),
    pass: env.get('DB_PASS').required().asString(),
    name: env.get('DB_NAME').required().asString(),
    sync: env.get('DB_SYNC').default(0).asBool(),
    dropEntities: env.get('DB_DROP_ENTITIES').default(0).asBool(),
  },

  smtp: {
    host: env.get('SMTP_HOST').required().asString(),
    port: env.get('SMTP_PORT').required().asPortNumber(),
    secure: env.get('SMTP_SECURE').required().default(1).asBool(),
    from: env.get('SMTP_FROM').required().asEmailString(),
    senderName: env.get('SMTP_SENDER_NAME').required().asString(),
    password: env.get('SMTP_PASSWORD').required().asString(),
  },

  secure: {
    jwt: {
      secret: env.get('JWT_SECRET').required().asString(),
      accessExpiresAt: env
        .get('JWT_ACCESS_TOKEN_EXPIRES')
        .default('15m')
        .asString(),
      refreshExpiresAt: env
        .get('JWT_REFRESH_TOKEN_EXPIRES')
        .default('30d')
        .asString(),
    },
    cookies: {
      secret: env.get('COOKIE_SECRET').required().asString(),
    },
  },

  adminUser: {
    username: env.get('ADMIN_USER_USERNAME').required().asString(),
    email: env.get('ADMIN_USER_EMAIL').required().asEmailString(),
    password: env.get('ADMIN_USER_PASSWORD').required().asString(),
  },

  discord: {
    clientId: env.get('DISCORD_CLIENT_ID').required().asString(),
    clientSecret: env.get('DISCORD_CLIENT_SECRET').required().asString(),
    redirectUrl: env.get('DISCORD_REDIRECT_URL').required().asUrlObject(),
  },

  widgets: {
    discord: {
      enabled: env.get('WIDGETS_DISCORD_ENABLED').required().asBool(),
      guildId: env.get('WIDGETS_DISCORD_GUILD_ID').required().asString(),
      botToken: env.get('WIDGETS_DISCORD_BOT_TOKEN').required().asString(),
    },
    vk: {
      enabled: env.get('WIDGETS_VK_ENABLED').required().asBool(),
    },
  },
} as const;
