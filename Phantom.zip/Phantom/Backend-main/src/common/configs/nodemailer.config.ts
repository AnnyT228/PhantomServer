import { Options as SMTPOptions } from 'nodemailer/lib/smtp-transport';
import { Options as PoolOptions } from 'nodemailer/lib/smtp-pool';
import { envConfig } from '@common/configs/env.config';

export const nodemailerConfig: Readonly<SMTPOptions> = {
  host: envConfig.smtp.host,
  from: envConfig.smtp.from,
  sender: envConfig.smtp.senderName,
  port: envConfig.smtp.port,
  secure: envConfig.smtp.secure,
  auth: {
    user: envConfig.smtp.from,
    pass: envConfig.smtp.password,
  },
};

export const nodemailerPoolConfig: Readonly<PoolOptions> = {
  pool: true,
  maxConnections: 10,
  maxMessages: 100,
};
