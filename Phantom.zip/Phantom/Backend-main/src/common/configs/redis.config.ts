import { RedisOptions } from 'ioredis';
import { CacheModuleAsyncOptions } from '@nestjs/cache-manager';
import { Logger } from '@nestjs/common';
import { redisStore } from 'cache-manager-ioredis-yet';
import { envConfig } from '@common/configs/env.config';

export const redisConfig: Readonly<RedisOptions> = {
  host: envConfig.redis.host,
  port: envConfig.redis.port,
  username: envConfig.redis.username,
  password: envConfig.redis.password,
  db: envConfig.redis.databaseIndex,
  connectionName: envConfig.redis.clientName,
  keyPrefix: envConfig.redis.keyPrefix,
  retryStrategy: () => 5000,
};

export const cacheModuleConfig: Readonly<CacheModuleAsyncOptions> = {
  isGlobal: true,
  useFactory: async () => {
    const redisLogger = new Logger('RedisClient');
    const redisStoreInstance = await redisStore(redisConfig);

    redisStoreInstance.client.on('error', (e) => redisLogger.error(e));
    redisStoreInstance.client.on('connect', () =>
      redisLogger.log('Successfully connected.'),
    );

    return {
      store: redisStoreInstance,
    };
  },
};
