import { DataSource, DataSourceOptions } from 'typeorm';
import { TypeOrmModuleOptions } from '@nestjs/typeorm';
import { resolve } from 'path';
import { envConfig } from '@common/configs/env.config';

export const typeormModuleConfig: Readonly<TypeOrmModuleOptions> = {
  type: 'postgres',
  host: envConfig.database.host,
  port: envConfig.database.port,
  username: envConfig.database.user,
  password: envConfig.database.pass,
  database: envConfig.database.name,
  entities: [resolve(process.cwd(), '**/*.entity.js')],
  autoLoadEntities: true,
  synchronize: envConfig.database.sync,
  dropSchema: envConfig.database.dropEntities,
  entityPrefix: envConfig.api.sitename.toLowerCase() + '_',
};

export const dataSource = new DataSource(
  typeormModuleConfig as DataSourceOptions,
);
