import { BadRequestException, ExecutionContext } from '@nestjs/common';
import { Request } from 'express';
import { createAdvancedParamDecorator } from '@common/other/create-advanced-param-decorator';

export const ValidatedBody = createAdvancedParamDecorator(
  (context: ExecutionContext, data: string) => {
    const request = context.switchToHttp().getRequest<Request>();
    const property = request.body[data];

    if (!property) throw new BadRequestException();

    return property;
  },
);
