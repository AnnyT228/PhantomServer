import {
  registerDecorator,
  ValidationArguments,
  ValidationOptions,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';

export function StringWithoutSpaces(validationOptions?: ValidationOptions) {
  return (object: object, propertyName: string) => {
    registerDecorator({
      target: object.constructor,
      propertyName: propertyName,
      constraints: [],
      options: validationOptions,
      validator: StringWithoutSpacesConstraint,
    });
  };
}

export const STRING_WITHOUT_SPACES_REGEX = /^\S+$/;

@ValidatorConstraint()
class StringWithoutSpacesConstraint implements ValidatorConstraintInterface {
  validate(string: string, args: ValidationArguments): boolean {
    return STRING_WITHOUT_SPACES_REGEX.test(string);
  }

  defaultMessage(args: ValidationArguments): string {
    return 'There should be no spaces in the string.';
  }
}
