export type SortType = 'ASC' | 'DESC';
export type SortLiteral = `${string}:${SortType}`;

type PropertyKeyFromSortLiteral<T extends SortLiteral> =
  T extends `${infer Key}:${SortType}` ? Key : never;
type GetSortType<T extends SortLiteral> =
  T extends `${string}:${infer SortType}` ? SortType : never;

interface Pagination {
  take: number;
  skip: number;
}

interface PaginationWithOrder<T extends SortLiteral> extends Pagination {
  order: {
    [Order in PropertyKeyFromSortLiteral<T>]: GetSortType<T>;
  };
}

export function getPagination(paginationOptions: {
  limit: number;
  page: number;
}): Pagination;

export function getPagination<T extends SortLiteral>(paginationOptions: {
  limit: number;
  page: number;
  sortBy: T;
}): PaginationWithOrder<T>;

export function getPagination<T extends SortLiteral>(options: {
  limit: number;
  page: number;
  sortBy?: T;
}): Pagination | PaginationWithOrder<T> {
  const [order, sortType] = (options.sortBy?.split(':') as [
    PropertyKeyFromSortLiteral<T>,
    GetSortType<T>,
  ]) || [undefined, undefined];

  return {
    take: options.limit,
    skip: options.limit * (options.page - 1),
    order: options.sortBy
      ? ({
          [order as PropertyKeyFromSortLiteral<T>]: sortType,
        } as {
          [Order in PropertyKeyFromSortLiteral<T>]: GetSortType<T>;
        })
      : undefined,
  };
}
