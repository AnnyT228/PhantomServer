import {
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsPositive,
  IsString,
  Max,
  Min,
} from 'class-validator';
import { Type } from 'class-transformer';
import { SortLiteral } from '@common/pagination/get-pagination';

export interface SortBy {
  sortBy: SortLiteral;
}

export class PaginationDto {
  @IsNotEmpty()
  @IsInt()
  @IsPositive()
  @Type(() => Number)
  page: number = 1;

  @IsOptional()
  @IsInt()
  @IsPositive()
  @Min(5)
  @Max(35)
  @Type(() => Number)
  limit: number = 10;

  @IsOptional()
  @IsString()
  includes?: string;
}
