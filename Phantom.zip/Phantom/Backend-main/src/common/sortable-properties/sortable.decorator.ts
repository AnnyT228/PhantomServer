export const SORTABLE_PROPERTY = 'sortableProperty';

export function Sortable(): PropertyDecorator {
  return (target: object, propertyKey: string | symbol) => {
    Reflect.defineMetadata(
      SORTABLE_PROPERTY,
      [...(Reflect.getMetadata(SORTABLE_PROPERTY, target) ?? []), propertyKey],
      target,
    );
  };
}
