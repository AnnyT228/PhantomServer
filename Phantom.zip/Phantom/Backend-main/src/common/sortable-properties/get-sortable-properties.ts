import 'reflect-metadata';
import { Type } from '@nestjs/common/interfaces';
import { SORTABLE_PROPERTY } from '@common/sortable-properties/sortable.decorator';
import { SortType } from '@common/pagination/get-pagination';

type SortableProperties = {
  [Key in `${string}${SortType}`]: `${string}:${SortType}`;
};

const globalSortablePropertiesStorage: Map<string, SortableProperties> =
  new Map();

export function getSortableProperties<T>(clazz: Type<T>): SortableProperties {
  const className = clazz.name;
  const cachedSortableProperties =
    globalSortablePropertiesStorage.get(className);

  if (cachedSortableProperties) return cachedSortableProperties;

  const sortableProperties = Reflect.getMetadata(
    SORTABLE_PROPERTY,
    clazz.prototype,
  ) as string[];

  if (!sortableProperties) {
    throw new Error(
      `The class ${className} has no fields labeled with the @Sortable() decorator`,
    );
  }

  const buildedProperties: SortableProperties = {};

  for (const property of sortableProperties) {
    buildedProperties[`${property}ASC`] = `${property}:ASC`;
    buildedProperties[`${property}DESC`] = `${property}:DESC`;
  }

  globalSortablePropertiesStorage.set(className, buildedProperties);

  return buildedProperties;
}
