import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EmailEntity } from '@/core/emails/entities/email.entity';
import { EmailsService } from './emails.service';
import { EmailsController } from './emails.controller';

@Module({
  imports: [TypeOrmModule.forFeature([EmailEntity])],
  providers: [EmailsService],
  controllers: [EmailsController],
  exports: [EmailsService, TypeOrmModule],
})
export class EmailsModule {}
