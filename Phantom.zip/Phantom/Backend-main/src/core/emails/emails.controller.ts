import { Controller, Post } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { EmailsService } from '@/core/emails/emails.service';
import { ValidatedBody } from '@common/validators/validated-body.decorator';

@ApiTags('emails')
@Controller('emails')
export class EmailsController {
  constructor(private readonly emailService: EmailsService) {}

  @Post('send/activate')
  sendActivate(@ValidatedBody('email') email: string): Promise<void> {
    return this.emailService.sendActivate(email);
  }

  @Post('send/reset-password')
  sendResetPassword(@ValidatedBody('email') email: string): Promise<void> {
    return this.emailService.sendResetPassword(email);
  }
}
