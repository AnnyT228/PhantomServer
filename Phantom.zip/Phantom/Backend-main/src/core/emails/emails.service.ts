import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { createTransport, SendMailOptions, Transporter } from 'nodemailer';
import { ThrottlerException } from '@nestjs/throttler';
import ms from 'ms';
import { EmailEntity } from '@/core/emails/entities/email.entity';
import { nodemailerConfig } from '@common/configs/nodemailer.config';
import { envConfig } from '@common/configs/env.config';

@Injectable()
export class EmailsService {
  private transporter: Transporter;

  constructor(
    @InjectRepository(EmailEntity)
    private readonly emailsRepository: Repository<EmailEntity>,
  ) {}

  private async sendMail(sendMailDto: SendMailOptions): Promise<void> {
    if (!this.transporter) {
      this.transporter = createTransport({ ...nodemailerConfig });
    }

    this.transporter
      .sendMail({
        ...sendMailDto,
        from: `${nodemailerConfig.sender} <${nodemailerConfig.from}>`,
      })
      .catch(() => {});
  }

  private async throwErrorByEmailsCount(
    email: string,
    type: 'activate' | 'resetPassword',
  ): Promise<void> {
    const existEmails = await this.emailsRepository.find({
      where: {
        email: email,
        type: type,
      },
    });
    const createdAt = existEmails.filter(
      (email) => email.createdAt > new Date(Date.now() - 5 * 60 * 1000),
    );

    if (existEmails.length >= 2 && !createdAt.length) {
      return void this.emailsRepository.remove(existEmails);
    }

    if (existEmails.length >= 2 && createdAt.length > 0) {
      throw new ThrottlerException();
    }
  }

  async sendActivate(email: string): Promise<void> {
    await this.throwErrorByEmailsCount(email, 'activate');

    const code = this.generateCode(6);

    const url = new URL('auth/confirm-activate', envConfig.api.frontendUrl);
    url.searchParams.append('code', code);

    await this.sendMail({
      to: email,
      subject: 'Подтверждение регистрации',
      text: `Ссылка для подтверждения регистрации - ${url}`,
    });

    this.emailsRepository.save({
      email: email,
      code: code,
      type: 'activate',
      expiresAt: new Date(Date.now() + ms('5m')),
    });
  }

  async sendResetPassword(email: string): Promise<void> {
    await this.throwErrorByEmailsCount(email, 'resetPassword');

    const code = this.generateCode(6);

    const url = new URL('auth/reset-password', envConfig.api.frontendUrl);
    url.searchParams.append('code', code);

    await this.sendMail({
      to: email,
      subject: 'Сброс пароля',
      text: `Ссылка для сброса пароля - ${url}`,
    });

    this.emailsRepository.save({
      email: email,
      code: code,
      type: 'resetPassword',
      expiresAt: new Date(Date.now() + ms('5m')),
    });
  }

  private generateCode(length: number): string {
    const codeArr: number[] = [];

    for (let i = 0; i < length; i++) {
      codeArr.push(Math.floor(Math.random() * 9) + 1);
    }

    return codeArr.join('');
  }
}
