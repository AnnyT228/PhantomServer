import {
  Column,
  CreateDateColumn,
  Entity,
  Generated,
  PrimaryColumn,
} from 'typeorm';

@Entity('emails')
export class EmailEntity {
  @PrimaryColumn()
  @Generated('increment')
  id: number;

  @Column()
  email: string;

  @Column()
  code: string;

  @Column()
  type: 'activate' | 'resetPassword' | string;

  @CreateDateColumn()
  expiresAt: Date;

  @CreateDateColumn()
  createdAt: Date;
}
