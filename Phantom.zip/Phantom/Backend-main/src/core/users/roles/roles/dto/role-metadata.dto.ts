import { Exclude, Expose } from 'class-transformer';
import { RoleEntity } from '@/core/users/roles/roles/entities/role.entity';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';
import { PermissionsService } from '@/core/users/roles/permissions/permissions.service';

@Exclude()
export class RoleMetadata {
  @Expose()
  roles: string[];

  @Expose()
  perms: string[];

  constructor(partial: Partial<RoleEntity[]>) {
    Object.assign(this, partial);
    this.roles = [];
    this.perms = [];

    partial.sort((a, b) => a.priority - b.priority);

    partial.map((role) => {
      this.roles.push(role.id);
      this.perms.push(...role.permissions);
      this.perms = PermissionsService.getInstance.transformPermissions(
        this.perms,
        Object.values(Permission),
      );
    });
  }
}
