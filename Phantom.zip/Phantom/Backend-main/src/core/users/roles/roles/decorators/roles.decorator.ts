import { Reflector } from '@nestjs/core';
import { Role } from '@/core/users/roles/roles/enums/roles.enum';

// export const ROLES_KEY = 'ROLES_KEY';
// export const Roles = (roles: Role[]): ReturnType<typeof Roles> =>
//   SetMetadata(ROLES_KEY, roles);

export const Roles = Reflector.createDecorator<Role[]>();
