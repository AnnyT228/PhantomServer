import { Exclude, Expose } from 'class-transformer';
import { Role } from '@/core/users/roles/roles/enums/roles.enum';
import { RoleEntity } from '@/core/users/roles/roles/entities/role.entity';

@Exclude()
export class RoleDto {
  @Expose()
  role: Role;

  @Expose()
  permissions: string[];

  @Expose()
  priority: number;

  @Expose()
  users: string[];

  constructor(partial: Partial<RoleEntity>) {
    Object.assign(this, partial);

    this.users = partial.users.map((user) => user.username);
  }
}
