import { Module, OnModuleInit } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RoleEntity } from '@/core/users/roles/roles/entities/role.entity';
import { RolesController } from '@/core/users/roles/roles/roles.controller';
import { UsersModule } from '@/core/users/users/users.module';
import { RolesService } from './roles.service';

@Module({
  imports: [TypeOrmModule.forFeature([RoleEntity]), UsersModule],
  controllers: [RolesController],
  providers: [RolesService],
  exports: [RolesService, TypeOrmModule],
})
export class RolesModule implements OnModuleInit {
  constructor(private readonly rolesService: RolesService) {}

  async onModuleInit(): Promise<any> {
    await this.rolesService.generateRootRoles();
  }
}
