import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { RolesService } from '@/core/users/roles/roles/roles.service';
import { CreateRoleDto } from '@/core/users/roles/roles/dto/create-role.dto';
import { ChangeRoleDto } from '@/core/users/roles/roles/dto/change-role.dto';
import { GetRolesQueryDto } from '@/core/users/roles/roles/dto/get-roles-query.dto';
import { Permissions } from '@/core/users/roles/permissions/decorators/permissions.decorator';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';
import {
  CurrentUser,
  ICurrentUser,
} from '@/core/users/users/decorators/current-user.decorator';
import { AuthGuard } from '@/core/auth/auth/guards/auth-guard.decorator';
import { ValidatedBody } from '@common/validators/validated-body.decorator';
import { RoleDto } from '@/core/users/roles/roles/dto/role.dto';
import { getPagination } from '@common/pagination/get-pagination';

@ApiTags('roles')
@Controller('roles')
export class RolesController {
  constructor(private readonly rolesService: RolesService) {}

  @Permissions([Permission.RolesApi])
  @Post()
  createRole(@Body() createRoleDto: CreateRoleDto): Promise<void> {
    return this.rolesService.createRole(createRoleDto);
  }

  @Permissions([Permission.RolesApi])
  @Patch(':role')
  changeRole(
    @Param('role') roleName: string,
    @Body() updateRoleDto: ChangeRoleDto,
  ): Promise<void> {
    return this.rolesService.changeRole(roleName, updateRoleDto);
  }

  @Permissions([Permission.RolesApi])
  @Patch('users/:username')
  changeUserRoles(
    @Param('username') username: string,
    @ValidatedBody('roles') roles: string[],
  ): Promise<void> {
    return this.rolesService.changeUserRoles(username, roles);
  }

  @Permissions([Permission.RolesApi])
  @Get(':role')
  getRoleByName(@Param('role') role: string): Promise<RoleDto> {
    return this.rolesService.findOneBy({ where: { id: role } }, true);
  }

  @AuthGuard()
  @Get('users/@me')
  getRolesMe(
    @CurrentUser() { userUUID }: ICurrentUser,
    @Query() getRolesQueryDto: GetRolesQueryDto,
  ): Promise<RoleDto[]> {
    return this.rolesService.getUserRoles(userUUID, getRolesQueryDto);
  }

  @Permissions([Permission.RolesApi])
  @Get('users/:username')
  getUserRoles(
    @Param('username') username: string,
    @Query() getRolesQueryDto: GetRolesQueryDto,
  ): Promise<RoleDto[]> {
    return this.rolesService.getUserRoles(username, getRolesQueryDto);
  }

  @Permissions([Permission.RolesApi])
  @Get()
  getAllRoles(@Query() getRolesQueryDto: GetRolesQueryDto): Promise<RoleDto[]> {
    return this.rolesService.findManyBy(
      {
        ...getPagination(getRolesQueryDto),
      },
      true,
    );
  }

  @Permissions([Permission.RolesApi])
  @Delete(':role')
  deleteRoleByName(@Param('role') role: string): Promise<void> {
    return this.rolesService.removeOneBy({ where: { id: role } });
  }
}
