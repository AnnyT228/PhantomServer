export enum Role {
  User = 'user',
  SuperUser = 'superuser',
}
