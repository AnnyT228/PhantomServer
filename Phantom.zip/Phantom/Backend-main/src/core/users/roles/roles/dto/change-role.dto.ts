import { PartialType } from '@nestjs/swagger';
import { CreateRoleDto } from '@/core/users/roles/roles/dto/create-role.dto';

export class ChangeRoleDto extends PartialType(CreateRoleDto) {}
