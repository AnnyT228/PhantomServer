import {
  ArrayNotEmpty,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsString,
} from 'class-validator';
import { StringWithoutSpaces } from '@common/validators/string-without-spaces.decorator';

export class CreateRoleDto {
  @IsNotEmpty()
  @IsString()
  @StringWithoutSpaces()
  name: string;

  @IsNotEmpty()
  @IsInt()
  priority: number;

  @IsArray()
  @ArrayNotEmpty()
  @IsString({ each: true })
  permissions: string[];
}
