import {
  BadRequestException,
  ConflictException,
  Injectable,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Raw, Repository } from 'typeorm';
import { RoleEntity } from '@/core/users/roles/roles/entities/role.entity';
import { Role } from '@/core/users/roles/roles/enums/roles.enum';
import { CreateRoleDto } from '@/core/users/roles/roles/dto/create-role.dto';
import { ChangeRoleDto } from '@/core/users/roles/roles/dto/change-role.dto';
import { UsersService } from '@/core/users/users/users.service';
import { RoleDto } from '@/core/users/roles/roles/dto/role.dto';
import { GetRolesQueryDto } from '@/core/users/roles/roles/dto/get-roles-query.dto';
import { getPagination } from '@common/pagination/get-pagination';
import { BaseEntityService } from '@common/other/abstract-base-entity.service';

@Injectable()
export class RolesService extends BaseEntityService<RoleEntity, RoleDto> {
  constructor(
    @InjectRepository(RoleEntity)
    private readonly rolesRepository: Repository<RoleEntity>,
    private readonly usersService: UsersService,
  ) {
    super(rolesRepository, RoleDto);
  }

  async generateRootRoles(): Promise<void> {
    if (!(await this.rolesRepository.findOne({ where: { id: Role.User } }))) {
      await this.rolesRepository.save({
        id: Role.User,
        priority: 0,
        permissions: ['user.*'],
      });
    }

    if (
      !(await this.rolesRepository.findOne({ where: { id: Role.SuperUser } }))
    ) {
      await this.rolesRepository.save({
        id: Role.SuperUser,
        priority: 1,
        permissions: ['*'],
      });
    }
  }

  async createRole(createRoleDto: CreateRoleDto): Promise<void> {
    const existRole = await this.rolesRepository.findOne({
      where: { id: createRoleDto.name as Role },
    });

    if (existRole) throw new ConflictException();

    await this.rolesRepository.save({ ...createRoleDto });
  }

  async changeRole(
    roleName: string,
    updateRoleDto: ChangeRoleDto,
  ): Promise<void> {
    const role = await this.findOneBy({ where: { id: roleName } });

    await this.rolesRepository.update({ id: role.id }, updateRoleDto);
  }

  async changeUserRoles(username: string, roles: string[]): Promise<void> {
    const user = await this.usersService.findOneBy({
      where: {
        username: username,
      },
    });

    const existRoles = await this.rolesRepository.findBy({
      id: Raw((alias) => `${alias} IN (:...roles)`, {
        roles: roles,
      }),
    });

    if (existRoles.length !== roles.length) throw new BadRequestException();

    await this.usersService.updateOneBy(user, { roles: existRoles });
  }

  async getUserRoles(
    usernameOrUUID: string,
    getRolesQueryDto: GetRolesQueryDto,
  ): Promise<RoleDto[]> {
    return await this.findManyBy(
      {
        where: [
          {
            users: {
              username: usernameOrUUID,
            },
          },
          {
            users: {
              id: usernameOrUUID,
            },
          },
        ],
        ...getPagination(getRolesQueryDto),
      },
      true,
    );
  }
}
