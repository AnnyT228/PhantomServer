import { IsEnum, IsNotEmpty } from 'class-validator';
import { PaginationDto, SortBy } from '@common/pagination/pagination.dto';
import { getSortableProperties } from '@common/sortable-properties/get-sortable-properties';
import { RoleEntity } from '@/core/users/roles/roles/entities/role.entity';
import { SortLiteral } from '@common/pagination/get-pagination';

export class GetRolesQueryDto extends PaginationDto implements SortBy {
  @IsNotEmpty()
  @IsEnum(getSortableProperties(RoleEntity))
  sortBy: SortLiteral;
}
