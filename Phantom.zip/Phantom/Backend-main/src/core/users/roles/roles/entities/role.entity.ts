import { Column, Entity, JoinTable, ManyToMany, PrimaryColumn } from 'typeorm';
import { UserEntity } from '@/core/users/users/entities/user.entity';
import { Role } from '@/core/users/roles/roles/enums/roles.enum';
import { Sortable } from '@common/sortable-properties/sortable.decorator';

@Entity('user_roles')
export class RoleEntity {
  @PrimaryColumn()
  @Sortable()
  id: Role | string;

  @ManyToMany(() => UserEntity, (userEntity) => userEntity.roles, {
    nullable: true,
  })
  @JoinTable({
    name: 'roles_users_join_table',
    joinColumn: {
      name: 'role',
      referencedColumnName: 'id',
    },
    inverseJoinColumn: {
      name: 'username',
      referencedColumnName: 'username',
    },
  })
  users: UserEntity[];

  @Column()
  @Sortable()
  priority: number;

  @Column('simple-array', {
    nullable: true,
  })
  permissions: string[];
}
