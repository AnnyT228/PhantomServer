import { Module } from '@nestjs/common';
import { RolesModule } from '@/core/users/roles/roles/roles.module';
import { PermissionsModule } from '@/core/users/roles/permissions/permissions.module';

@Module({
  imports: [RolesModule, PermissionsModule],
  exports: [RolesModule, PermissionsModule],
})
export class RolesMainModule {}
