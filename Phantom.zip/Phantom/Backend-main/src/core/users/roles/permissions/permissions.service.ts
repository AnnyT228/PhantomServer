import { Injectable } from '@nestjs/common';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';

@Injectable()
export class PermissionsService {
  private static permissionsService: PermissionsService;

  static set setInstance(instance: PermissionsService) {
    this.permissionsService = instance;
  }

  static get getInstance(): PermissionsService {
    return this.permissionsService;
  }

  matchPermissions(
    ownPermissions: string[],
    requiredPermissions: string[],
  ): boolean {
    const transform = this.transformPermissions(
      ownPermissions,
      Object.values(Permission),
    );

    return requiredPermissions.every((perm) => transform.includes(perm));
  }

  transformPermissions(
    ownPermissions: string[],
    requiredPermissions: string[],
  ): string[] {
    const matchingPermissions: string[] = [];
    const antiPermissions: string[] = [];

    for (const ownPermission of ownPermissions) {
      if (ownPermission.startsWith('!')) {
        antiPermissions.push(ownPermission.slice(1));
      }
    }

    for (const requiredPermission of requiredPermissions) {
      let permissionFound = false;

      for (const ownPermission of ownPermissions) {
        const isAntiPermission = ownPermission.startsWith('!');
        const permission = isAntiPermission
          ? ownPermission.slice(1)
          : ownPermission;

        if (requiredPermission === permission) {
          permissionFound = true;
        }

        if (permission.endsWith('*')) {
          const template = permission.slice(0, -2);

          if (requiredPermission.startsWith(template)) {
            permissionFound = true;
          }
        }
      }

      const isAntiPermission = antiPermissions.some((antiPermission) =>
        requiredPermission.startsWith(
          antiPermission.endsWith('*')
            ? antiPermission.slice(0, -2)
            : antiPermission,
        ),
      );

      if (permissionFound && !isAntiPermission) {
        matchingPermissions.push(requiredPermission);
      }
    }

    return matchingPermissions;
  }
}
