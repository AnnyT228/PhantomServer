import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
  mixin,
} from '@nestjs/common';
import { Socket } from 'socket.io';
import { Request } from 'express';
import { ApiKeysService } from '@/core/auth/tokens/api-keys/api-keys.service';
import { AuthTokensHelper } from '@/core/auth/tokens/tokens/auth-tokens-helper.service';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';

export const WsPermissionGuard = (
  permissions: Permission[],
): ReturnType<typeof WsPermissionGuard> => {
  @Injectable()
  class WsPermissionGuardMixin implements CanActivate {
    constructor(
      public readonly apiKeysService: ApiKeysService,
      public readonly authTokensHelper: AuthTokensHelper,
    ) {}

    async canActivate(context: ExecutionContext): Promise<boolean> {
      const client = context.switchToWs().getClient<Socket>();

      const { type, token } = {
        ...this.authTokensHelper.extractTokenFromHeader(
          client.request as Request,
        ),
      };

      if (!token || type === 'Access-Token') throw new ForbiddenException();

      const access = await this.apiKeysService.validateApiKey(
        token,
        permissions,
      );

      if (!access) throw new ForbiddenException();

      return true;
    }
  }

  return mixin(WsPermissionGuardMixin);
};
