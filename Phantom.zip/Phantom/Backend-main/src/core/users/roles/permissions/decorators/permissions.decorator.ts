import { Reflector } from '@nestjs/core';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';

// export const PERMISSIONS_KEY = 'PERMISSIONS_KEY';
// export const Permissions = (
//   permissions: Permission[],
// ): ReturnType<typeof Permissions> => SetMetadata(PERMISSIONS_KEY, permissions);

export const Permissions = Reflector.createDecorator<Permission[]>();
