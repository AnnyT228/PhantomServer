import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  HttpStatus,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ApiException } from '@common/api-exceptions/api-exception.error';
import { AuthTokensHelper } from '@/core/auth/tokens/tokens/auth-tokens-helper.service';
import { PermissionsService } from '@/core/users/roles/permissions/permissions.service';
import { ApiKeysService } from '@/core/auth/tokens/api-keys/api-keys.service';
import { Exceptions } from '@common/api-exceptions/exceptions.namespace';
import { Permissions } from '@/core/users/roles/permissions/decorators/permissions.decorator';

@Injectable()
export class PermissionGuard implements CanActivate {
  constructor(
    private readonly apiKeysService: ApiKeysService,
    private readonly authTokensHelper: AuthTokensHelper,
    private readonly permissionsService: PermissionsService,
    private readonly reflector: Reflector,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const requiredPerms = this.reflector.getAllAndOverride(Permissions, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!requiredPerms) return true;

    const request = context.switchToHttp().getRequest();

    const { token, type } = {
      ...this.authTokensHelper.extractTokenFromHeader(request),
    };

    if (!token) throw new ForbiddenException();

    if (type === 'Access-Token') {
      const user = await this.authTokensHelper.getUserPermsFromToken(token);

      return this.permissionsService.matchPermissions(
        user.perms,
        requiredPerms,
      );
    }

    const apiKey = await this.apiKeysService
      .validateApiKey(token, requiredPerms)
      .catch((e) => {
        if (e instanceof NotFoundException) {
          throw new ForbiddenException();
        }

        throw e;
      });

    if (!apiKey) {
      throw new ApiException(
        HttpStatus.FORBIDDEN,
        'PermissionsExceptions',
        Exceptions.PermissionsExceptions.ApiKeyNoSuchPermissions,
      );
    }

    return true;
  }
}
