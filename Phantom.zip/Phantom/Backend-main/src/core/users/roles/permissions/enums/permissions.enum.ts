export enum Permission {
  // Endpoints
  // For users
  UsersApi = 'kernel.users.api',
  RolesApi = 'kernel.users.roles.api',
  AssetsApi = 'kernel.users.assets.api',

  // For Gravit
  GravitApi = 'kernel.auth.gravit.api',

  // For servers
  ServersApi = 'kernel.servers.api',
  ServersMonitoringsApi = 'kernel.servers.monitorings.api',

  // For tokens
  ApiKeysApi = 'kernel.tokens.api-keys.api',
  SessionsApi = 'kernel.tokens.sessions.api',

  // For news
  NewsApi = 'kernel.news.api',
  CommentsApi = 'kernel.news.comments.api',

  // Admin
  AdminDefaultAccess = 'admin.default.access',
}
