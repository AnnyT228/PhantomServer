import { Module, OnModuleInit } from '@nestjs/common';
import { PermissionsService } from '@/core/users/roles/permissions/permissions.service';

@Module({
  providers: [PermissionsService],
  exports: [PermissionsService],
})
export class PermissionsModule implements OnModuleInit {
  constructor(private readonly permissionsService: PermissionsService) {}

  onModuleInit(): any {
    PermissionsService.setInstance = this.permissionsService;
  }
}
