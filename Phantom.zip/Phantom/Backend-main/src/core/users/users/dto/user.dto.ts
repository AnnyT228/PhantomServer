import { Exclude, Expose } from 'class-transformer';
import { UserEntity } from '@/core/users/users/entities/user.entity';
import { RoleMetadata } from '@/core/users/roles/roles/dto/role-metadata.dto';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';
import { PermissionsService } from '@/core/users/roles/permissions/permissions.service';
import { AssetsDto } from '@/core/users/assets/dto/assets.dto';

@Exclude()
export class UserDto {
  @Expose()
  id: string;

  @Expose()
  username: string;

  @Expose()
  email: string;

  @Expose()
  permissions: RoleMetadata;

  @Expose()
  assets: AssetsDto;

  @Expose()
  createdAt: Date;

  constructor(partial: Partial<UserEntity>) {
    Object.assign(this, partial);
    this.permissions = new RoleMetadata(partial.roles) ?? null;
    this.assets = new AssetsDto(partial.skin, partial.cape);
    this.permissions.perms =
      PermissionsService.getInstance.transformPermissions(
        this.permissions.perms,
        Object.values(Permission),
      );
  }
}
