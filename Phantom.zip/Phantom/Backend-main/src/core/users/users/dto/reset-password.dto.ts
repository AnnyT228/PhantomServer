import { IsEmail, IsNotEmpty, IsString, Length } from 'class-validator';
import { StringWithoutSpaces } from '@common/validators/string-without-spaces.decorator';

export class ResetPasswordDto {
  @IsNotEmpty()
  @IsEmail()
  email: string;

  @IsNotEmpty()
  @Length(6, 32)
  @IsString()
  @StringWithoutSpaces()
  password: string;

  @IsNotEmpty()
  @IsString()
  @StringWithoutSpaces()
  code: string;
}
