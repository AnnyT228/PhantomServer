import { IsEnum, IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { PaginationDto, SortBy } from '@common/pagination/pagination.dto';
import { getSortableProperties } from '@common/sortable-properties/get-sortable-properties';
import { UserEntity } from '@/core/users/users/entities/user.entity';
import { SortLiteral } from '@common/pagination/get-pagination';

export class GetUsersCount {
  @IsOptional()
  @IsString()
  includes?: string;
}

export class GetUsersQueryDto extends PaginationDto implements SortBy {
  @IsNotEmpty()
  @IsEnum(getSortableProperties(UserEntity))
  sortBy: SortLiteral;
}
