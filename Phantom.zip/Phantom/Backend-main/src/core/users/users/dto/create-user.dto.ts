import {
  IsBoolean,
  IsEmail,
  IsNotEmpty,
  IsOptional,
  IsString,
  Length,
} from 'class-validator';
import { StringWithoutSpaces } from '@common/validators/string-without-spaces.decorator';

export class CreateUserDto {
  @IsNotEmpty()
  @Length(3, 16)
  @IsString()
  @StringWithoutSpaces()
  username: string;

  @IsNotEmpty()
  @IsEmail()
  @StringWithoutSpaces()
  email: string;

  @IsNotEmpty()
  @Length(6, 32)
  @IsString()
  @StringWithoutSpaces()
  password: string;

  @IsOptional()
  @IsBoolean()
  activated?: boolean;

  @IsOptional()
  @IsString({ each: true })
  roles?: string[];
}
