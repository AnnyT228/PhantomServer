import { HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { Like, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { hash } from 'bcrypt';
import { UserEntity } from '@/core/users/users/entities/user.entity';
import { CreateUserDto } from '@/core/users/users/dto/create-user.dto';
import { ApiException } from '@common/api-exceptions/api-exception.error';
import { ResetPasswordDto } from '@/core/users/users/dto/reset-password.dto';
import { EmailEntity } from '@/core/emails/entities/email.entity';
import { BaseEntityService } from '@common/other/abstract-base-entity.service';
import { EmailsService } from '@/core/emails/emails.service';
import { UserDto } from '@/core/users/users/dto/user.dto';
import { Exceptions } from '@common/api-exceptions/exceptions.namespace';

@Injectable()
export class UsersService extends BaseEntityService<UserEntity, UserDto> {
  constructor(
    @InjectRepository(UserEntity)
    private readonly usersRepository: Repository<UserEntity>,
    @InjectRepository(EmailEntity)
    private readonly emailsRepository: Repository<EmailEntity>,
    private readonly emailService: EmailsService,
  ) {
    super(usersRepository, UserDto);
  }

  async createUser(createUserDto: CreateUserDto): Promise<UserEntity> {
    const existUser = await this.usersRepository.findOne({
      where: [
        { username: createUserDto.username },
        { email: createUserDto.email },
      ],
    });

    if (existUser) {
      throw new ApiException(
        HttpStatus.BAD_REQUEST,
        'UsersExceptions',
        Exceptions.UsersExceptions.UserExist,
      );
    }

    if (!createUserDto.activated) {
      await this.emailService.sendActivate(createUserDto.username);
    }

    return await this.usersRepository.save({
      username: createUserDto.username,
      email: createUserDto.email,
      password: await hash(createUserDto.password, 10),
      roles: createUserDto.roles?.map((role) => ({ id: role })) ?? [
        {
          id: 'user',
        },
      ],
      activated: createUserDto.activated ?? false,
    });
  }

  async usersCount(usernameOrEmail?: string): Promise<{ count: number }> {
    return {
      count: await this.usersRepository.count({
        where: usernameOrEmail
          ? [
              { username: Like(`%${usernameOrEmail}%`) },
              { email: Like(`%${usernameOrEmail}%`) },
            ]
          : undefined,
      }),
    };
  }

  async updateUserPassword(
    usernameOrUuid: string,
    password: string,
  ): Promise<void> {
    const user = await this.findOneBy({
      where: [
        {
          username: usernameOrUuid,
        },
        { id: usernameOrUuid },
      ],
    });

    await this.updateOneBy(user, { password: await hash(password, 10) });
  }

  async updateUserEmail(usernameOrUuid: string, email: string): Promise<void> {
    const user = await this.findOneBy({
      where: [{ username: usernameOrUuid }, { id: usernameOrUuid }],
    });

    await this.updateOneBy(user, { email: email });
  }

  async confirmResetPassword(
    resetPasswordDto: ResetPasswordDto,
  ): Promise<void> {
    const existRecord = await this.emailsRepository.findOne({
      where: {
        email: resetPasswordDto.email,
        code: resetPasswordDto.code,
        type: 'resetPassword',
      },
    });

    if (!existRecord) throw new NotFoundException();

    if (existRecord.expiresAt < new Date(Date.now())) {
      this.emailsRepository.remove(existRecord).catch(() => {});

      throw new ApiException(
        HttpStatus.BAD_REQUEST,
        'LinksExceptions',
        Exceptions.LinksExceptions.PasswordResetLinkExpired,
      );
    }
    this.emailsRepository.remove(existRecord).catch(() => {});

    await this.updateOneBy(
      { where: { email: resetPasswordDto.email } },
      { password: await hash(resetPasswordDto.password, 10) },
    );
  }

  async confirmActivate(code: string): Promise<void> {
    const existRecord = await this.emailsRepository.findOne({
      where: { code: code, type: 'activate' },
    });
    if (!existRecord) throw new NotFoundException();

    const user = await this.usersRepository.findOne({
      where: { email: existRecord.email },
    });
    if (!user) {
      throw new ApiException(
        HttpStatus.NOT_FOUND,
        'UsersExceptions',
        Exceptions.UsersExceptions.UserNotFound,
      );
    }

    if (existRecord.expiresAt < new Date(Date.now())) {
      this.emailsRepository.remove(existRecord).catch(() => {});

      throw new ApiException(
        HttpStatus.BAD_REQUEST,
        'LinksExceptions',
        Exceptions.LinksExceptions.ActivationLinkExpired,
      );
    }

    await this.updateOneBy(
      { where: { email: existRecord.email } },
      { activated: true },
    );

    this.emailsRepository.remove(existRecord).catch(() => {});
  }
}
