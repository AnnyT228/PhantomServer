import {
  Column,
  CreateDateColumn,
  Entity,
  Generated,
  JoinColumn,
  JoinTable,
  ManyToMany,
  OneToOne,
  PrimaryColumn,
} from 'typeorm';
import { RoleEntity } from '@/core/users/roles/roles/entities/role.entity';
import { CapeEntity } from '@/core/users/assets/capes/entities/cape.entity';
import { SkinEntity } from '@/core/users/assets/skins/entities/skin.entity';
import { DiscordUserEntity } from '@/core/auth/oauth/discord/entities/discord-user.entity';
import { Sortable } from '@common/sortable-properties/sortable.decorator';

@Entity('users')
export class UserEntity {
  @PrimaryColumn()
  @Generated('uuid')
  id: string;

  @Column({ unique: true })
  @Sortable()
  username: string;

  @Column({ unique: true })
  @Sortable()
  email: string;

  @Column()
  password: string;

  @OneToOne(() => DiscordUserEntity, (discordUser) => discordUser.user, {
    eager: true,
    nullable: true,
    onUpdate: 'CASCADE',
  })
  @JoinColumn()
  discord: DiscordUserEntity;

  @ManyToMany(() => RoleEntity, (role) => role.users, {
    eager: true,
    cascade: true,
  })
  @JoinTable({
    name: 'users_roles_join_table',
    joinColumn: {
      name: 'user',
      referencedColumnName: 'username',
    },
    inverseJoinColumn: {
      name: 'role',
      referencedColumnName: 'id',
    },
  })
  roles: RoleEntity[];

  @OneToOne(() => SkinEntity, (skin) => skin.user, {
    eager: true,
    nullable: true,
    cascade: true,
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  skin: SkinEntity;

  @OneToOne(() => CapeEntity, (cape) => cape.user, {
    eager: true,
    nullable: true,
    cascade: true,
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  cape: CapeEntity;

  @Column({ default: false })
  activated: boolean;

  @CreateDateColumn()
  @Sortable()
  createdAt: Date;
}
