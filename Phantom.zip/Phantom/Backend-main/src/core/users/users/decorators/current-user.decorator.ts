import { ExecutionContext } from '@nestjs/common';
import { Request } from 'express';
import { GetJwtPayload } from '@/core/auth/tokens/tokens/dto/jwt-payload.dto';
import { createAdvancedParamDecorator } from '@common/other/create-advanced-param-decorator';

export interface ICurrentUser {
  tokenId: string;
  userUUID: string;
}

export const CurrentUser = createAdvancedParamDecorator(
  (ctx: ExecutionContext): ICurrentUser => {
    const request = ctx.switchToHttp().getRequest<Request>();
    const user: Pick<GetJwtPayload, 'user' | 'id'> = request['user'];

    return {
      tokenId: user.id,
      userUUID: user.user,
    };
  },
);
