import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Like, Raw } from 'typeorm';
import { UsersService } from '@/core/users/users/users.service';
import { CreateUserDto } from '@/core/users/users/dto/create-user.dto';
import {
  CurrentUser,
  ICurrentUser,
} from '@/core/users/users/decorators/current-user.decorator';
import { Permissions } from '@/core/users/roles/permissions/decorators/permissions.decorator';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';
import { AuthGuard } from '@/core/auth/auth/guards/auth-guard.decorator';
import { ResetPasswordDto } from '@/core/users/users/dto/reset-password.dto';
import {
  GetUsersCount,
  GetUsersQueryDto,
} from '@/core/users/users/dto/get-users-query.dto';
import { ValidatedBody } from '@common/validators/validated-body.decorator';
import { getPagination } from '@common/pagination/get-pagination';
import { UserEntity } from '@/core/users/users/entities/user.entity';
import { UserDto } from '@/core/users/users/dto/user.dto';

@ApiTags('users')
@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Permissions([Permission.UsersApi])
  @Post()
  createUser(@Body() createUserDto: CreateUserDto): Promise<UserEntity> {
    return this.usersService.createUser(createUserDto);
  }

  @AuthGuard()
  @Get('@me')
  getUserMe(@CurrentUser() user: ICurrentUser): Promise<UserDto> {
    return this.usersService.findOneBy({ where: { id: user.userUUID } }, true);
  }

  @Permissions([Permission.UsersApi])
  @Get()
  getAllUsers(@Query() getUsersDto: GetUsersQueryDto): Promise<UserDto[]> {
    return this.usersService.findManyBy(
      {
        where: getUsersDto.includes
          ? [
              { username: Like(`%${getUsersDto.includes}%`) },
              { email: Like(`%${getUsersDto.includes}%`) },
            ]
          : undefined,
        ...getPagination(getUsersDto),
      },
      true,
    );
  }

  @Get('count')
  getUsersCount(
    @Query() getUsersCount: GetUsersCount,
  ): Promise<{ count: number }> {
    return this.usersService.usersCount(getUsersCount.includes);
  }

  @Permissions([Permission.UsersApi])
  @Get(':username')
  getUserByUsername(@Param('username') username: string): Promise<UserDto> {
    return this.usersService.findOneBy({ where: { username } }, true);
  }

  @AuthGuard()
  @Patch('@me/password')
  changePasswordMe(
    @CurrentUser() user: ICurrentUser,
    @ValidatedBody('password') password: string,
  ): Promise<void> {
    return this.usersService.updateUserPassword(user.userUUID, password);
  }

  @Permissions([Permission.UsersApi])
  @Patch(':username/password')
  changeUserPassword(
    @Param('username') username: string,
    @ValidatedBody('password') password: string,
  ): Promise<void> {
    return this.usersService.updateUserPassword(username, password);
  }

  @AuthGuard()
  @Patch('@me/emails')
  changeEmailMe(
    @CurrentUser() user: ICurrentUser,
    @ValidatedBody('email') email: string,
  ): Promise<void> {
    return this.usersService.updateUserEmail(user.userUUID, email);
  }

  @Permissions([Permission.UsersApi])
  @Patch(':username/emails')
  changeUserEmail(
    @Param('username') username: string,
    @ValidatedBody('email') email: string,
  ): Promise<void> {
    return this.usersService.updateUserEmail(username, email);
  }

  @Get('confirm/activate/:code')
  confirmActivate(@Param('code') code: string): Promise<void> {
    return this.usersService.confirmActivate(code);
  }

  @Post('confirm/reset-password')
  confirmResetPassword(
    @Body() resetPasswordDto: ResetPasswordDto,
  ): Promise<void> {
    return this.usersService.confirmResetPassword(resetPasswordDto);
  }

  @Permissions([Permission.UsersApi])
  @Delete(':username')
  deleteUserByUsername(@Param('username') username: string): Promise<void> {
    return this.usersService.removeOneBy({
      where: { username: username },
    });
  }

  @Permissions([Permission.UsersApi])
  @Delete()
  deleteUsersByUsernames(
    @ValidatedBody('usernames') usernames: string[],
  ): Promise<void> {
    return this.usersService.removeManyBy({
      where: {
        username: Raw((alias) => `${alias} IN (:...usernames)`, {
          usernames: usernames,
        }),
      },
    });
  }
}
