import { Module, OnModuleInit } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserEntity } from '@/core/users/users/entities/user.entity';
import { EmailsModule } from '@/core/emails/emails.module';
import { UsersController } from '@/core/users/users/users.controller';
import { UsersService } from '@/core/users/users/users.service';
import { RoleEntity } from '@/core/users/roles/roles/entities/role.entity';
import { envConfig } from '@common/configs/env.config';

@Module({
  imports: [TypeOrmModule.forFeature([UserEntity, RoleEntity]), EmailsModule],
  controllers: [UsersController],
  providers: [UsersService],
  exports: [UsersService, TypeOrmModule],
})
export class UsersModule implements OnModuleInit {
  constructor(private readonly usersService: UsersService) {}

  async onModuleInit(): Promise<any> {
    return await this.usersService
      .createUser({
        username: envConfig.adminUser.username,
        email: envConfig.adminUser.email,
        password: envConfig.adminUser.password,
        activated: true,
        roles: ['superuser'],
      })
      .catch(() => {});
  }
}
