import { Module } from '@nestjs/common';
import { UsersModule } from '@/core/users/users/users.module';
import { RolesMainModule } from '@/core/users/roles/roles-main.module';
import { UsersAssetsMainModule } from '@/core/users/assets/users-assets-main.module';

@Module({
  imports: [UsersModule, RolesMainModule, UsersAssetsMainModule],
  exports: [UsersModule, RolesMainModule, UsersAssetsMainModule],
})
export class UsersMainModule {}
