import { Module } from '@nestjs/common';
import { SkinsModule } from '@/core/users/assets/skins/skins.module';
import { CapesModule } from '@/core/users/assets/capes/capes.module';

@Module({
  imports: [SkinsModule, CapesModule],
  exports: [SkinsModule, CapesModule],
})
export class UsersAssetsMainModule {}
