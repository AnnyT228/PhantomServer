import {
  Controller,
  DefaultValuePipe,
  Delete,
  Get,
  Header,
  Param,
  Patch,
  Query,
  StreamableFile,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { SkinsService } from '@/core/users/assets/skins/skins.service';
import { AuthGuard } from '@/core/auth/auth/guards/auth-guard.decorator';
import { FileHandler } from '@common/other/file-handler';
import {
  CurrentUser,
  ICurrentUser,
} from '@/core/users/users/decorators/current-user.decorator';
import { FileValidationPipe } from '@common/pipes/file-validation.pipe';
import { Permissions } from '@/core/users/roles/permissions/decorators/permissions.decorator';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';

@ApiTags('assets')
@Controller('users/assets')
export class SkinsController {
  constructor(private readonly skinsService: SkinsService) {}

  @Get(':username/skin')
  @Header('Content-Type', 'image/png')
  streamSkinByUsername(
    @Param('username') username: string,
    @Query('defaultSkin', new DefaultValuePipe(false)) defaultSkin: boolean,
  ): Promise<StreamableFile> {
    return this.skinsService.streamSkinByUsername(username, defaultSkin);
  }

  @Get(':username/head')
  @Header('Content-Type', 'image/png')
  streamHeadByUsername(
    @Param('username') username: string,
    @Query('defaultSkin', new DefaultValuePipe(false)) defaultSkin: boolean,
  ): Promise<StreamableFile> {
    return this.skinsService.streamHeadByUsername(username, defaultSkin);
  }

  @AuthGuard()
  @Patch('@me/skin')
  @UseInterceptors(FileHandler)
  changeSkinMe(
    @CurrentUser() user: ICurrentUser,
    @UploadedFile(new FileValidationPipe({ maxSizeInMiB: 0.5 }))
    file: Express.Multer.File,
  ): Promise<void> {
    return this.skinsService.changeSkin(user.userUUID, file);
  }

  @Permissions([Permission.AssetsApi])
  @Patch(':username/skin')
  @UseInterceptors(FileHandler)
  changeSkin(
    @Param('username') username: string,
    @UploadedFile(new FileValidationPipe({ maxSizeInMiB: 0.5 }))
    file: Express.Multer.File,
  ): Promise<void> {
    return this.skinsService.changeSkin(username, file);
  }

  @AuthGuard()
  @Delete('@me/skin')
  removeSkinMe(@CurrentUser() user: ICurrentUser): Promise<void> {
    return this.skinsService.removeSkin(user.userUUID);
  }

  @Permissions([Permission.AssetsApi])
  @Delete(':username/skin')
  removeSkin(@Param('username') username: string): Promise<void> {
    return this.skinsService.removeSkin(username);
  }
}
