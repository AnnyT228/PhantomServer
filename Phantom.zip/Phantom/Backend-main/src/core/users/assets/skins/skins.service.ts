import {
  Injectable,
  NotFoundException,
  StreamableFile,
  UnsupportedMediaTypeException,
} from '@nestjs/common';
import { MinecraftSkinConverter } from 'minecraft-skin-converter';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { SkinEntity } from '@/core/users/assets/skins/entities/skin.entity';
import { StorageService } from '@/core/storage/storage.service';
import { DEFAULT_SKIN_BUFFER } from '@common/other/default-skin-buffer';
import { MemoryStorageFile } from '@/core/storage/types/memory-storage-file.type';
import { UsersService } from '@/core/users/users/users.service';

@Injectable()
export class SkinsService {
  private skinConverter: MinecraftSkinConverter<'buffer/png'>;

  constructor(
    @InjectRepository(SkinEntity)
    private readonly skinsRepository: Repository<SkinEntity>,
    private readonly usersService: UsersService,
    private readonly storageService: StorageService,
  ) {}

  async streamSkinByUsername(
    username: string,
    defaultSkin: boolean,
  ): Promise<StreamableFile> {
    const user = await this.usersService.findOneBy({
      where: { username: username },
    });

    if (!user.skin && !defaultSkin) throw new NotFoundException();

    const file = await this.storageService.readFile(user.skin?.fileName);

    return user.skin
      ? new StreamableFile(file)
      : new StreamableFile(DEFAULT_SKIN_BUFFER);
  }

  async streamHeadByUsername(
    username: string,
    defaultSkin: boolean,
  ): Promise<StreamableFile> {
    const user = await this.usersService.findOneBy({
      where: { username: username },
    });

    if (!user.skin && !defaultSkin) throw new NotFoundException();

    const file = await this.storageService.readFile(user.skin?.fileName);

    this.skinConverter = new MinecraftSkinConverter(
      file || DEFAULT_SKIN_BUFFER,
      'buffer/png',
    );
    const head = (await this.skinConverter.getSkinHead(64)).data;

    return new StreamableFile(head);
  }

  async changeSkin(
    usernameOrUUID: string,
    file: MemoryStorageFile,
  ): Promise<void> {
    const user = await this.usersService.findOneBy({
      where: [{ id: usernameOrUUID }, { username: usernameOrUUID }],
    });

    const skin = user.skin || this.skinsRepository.create();

    if (user.skin) await this.storageService.removeFile(user.skin.fileName);

    this.skinConverter = new MinecraftSkinConverter(file.buffer, 'buffer/png');
    const convertedSkin = await this.skinConverter.convertSkin().catch(() => {
      throw new UnsupportedMediaTypeException();
    });

    skin.user = user;
    skin.slim = convertedSkin.slim;
    skin.fileName = await this.storageService.saveFile(file.buffer);
    skin.digest = this.storageService.getFileDigest(convertedSkin.data);

    await this.skinsRepository.save(skin);
  }

  async removeSkin(usernameOrUUID: string): Promise<void> {
    const user = await this.usersService.findOneBy({
      where: [{ id: usernameOrUUID }, { username: usernameOrUUID }],
    });

    if (!user.skin) throw new NotFoundException();

    await Promise.all([
      this.storageService.removeFile(user.skin.fileName),
      this.skinsRepository.remove(user.skin),
    ]);
  }
}
