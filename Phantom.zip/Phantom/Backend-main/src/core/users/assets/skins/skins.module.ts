import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SkinsController } from '@/core/users/assets/skins/skins.controller';
import { SkinsService } from '@/core/users/assets/skins/skins.service';
import { StorageModule } from '@/core/storage/storage.module';
import { UsersModule } from '@/core/users/users/users.module';
import { SkinEntity } from '@/core/users/assets/skins/entities/skin.entity';

@Module({
  imports: [TypeOrmModule.forFeature([SkinEntity]), StorageModule, UsersModule],
  controllers: [SkinsController],
  providers: [SkinsService],
  exports: [SkinsService, TypeOrmModule],
})
export class SkinsModule {}
