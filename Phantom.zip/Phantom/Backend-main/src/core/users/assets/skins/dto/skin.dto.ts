import { Exclude, Expose } from 'class-transformer';
import { SkinEntity } from '@/core/users/assets/skins/entities/skin.entity';
import { StorageService } from '@/core/storage/storage.service';

@Exclude()
export class SkinDto {
  @Expose()
  url: string;

  @Expose()
  digest: string;

  @Expose()
  metadata: {
    model?: 'slim';
  };

  constructor(skinEntity: SkinEntity) {
    Object.assign(this, skinEntity);

    this.url = StorageService.getInstance
      .getFileUrl(skinEntity.fileName)
      .toString();
    this.metadata = skinEntity.slim ? { model: 'slim' } : undefined;
  }
}
