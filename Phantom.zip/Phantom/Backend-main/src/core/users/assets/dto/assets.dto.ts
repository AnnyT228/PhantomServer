import { SkinDto } from '@/core/users/assets/skins/dto/skin.dto';
import { CapeDto } from '@/core/users/assets/capes/dto/cape.dto';
import { SkinEntity } from '@/core/users/assets/skins/entities/skin.entity';
import { CapeEntity } from '@/core/users/assets/capes/entities/cape.entity';

export class AssetsDto {
  SKIN: SkinDto;
  CAPE: CapeDto;

  constructor(skin?: SkinEntity, cape?: CapeEntity) {
    this.SKIN = skin ? new SkinDto(skin) : undefined;
    this.CAPE = cape ? new CapeDto(cape) : undefined;
  }
}
