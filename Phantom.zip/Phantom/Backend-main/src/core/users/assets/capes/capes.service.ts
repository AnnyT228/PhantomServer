import { Injectable, NotFoundException, StreamableFile } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UsersService } from '@/core/users/users/users.service';
import { StorageService } from '@/core/storage/storage.service';
import { CapeEntity } from '@/core/users/assets/capes/entities/cape.entity';
import { MemoryStorageFile } from '@/core/storage/types/memory-storage-file.type';

@Injectable()
export class CapesService {
  constructor(
    @InjectRepository(CapeEntity)
    private readonly capesRepository: Repository<CapeEntity>,
    private readonly usersService: UsersService,
    private readonly storageService: StorageService,
  ) {}

  async streamCapeByUsername(username: string): Promise<StreamableFile> {
    const user = await this.usersService.findOneBy({
      where: { username: username },
    });

    if (!user.cape) throw new NotFoundException();

    const file = await this.storageService.readFile(user.cape.fileName);

    return new StreamableFile(file);
  }

  async changeCape(
    usernameOrUUID: string,
    file: MemoryStorageFile,
  ): Promise<void> {
    const user = await this.usersService.findOneBy({
      where: [{ id: usernameOrUUID }, { username: usernameOrUUID }],
    });

    const cape = user.cape || this.capesRepository.create();

    if (user.cape) await this.storageService.removeFile(user.cape.fileName);

    cape.user = user;
    cape.fileName = await this.storageService.saveFile(file.buffer);
    cape.digest = this.storageService.getFileDigest(file.buffer);

    await this.capesRepository.save(cape);
  }

  async removeCape(usernameOrUUID: string): Promise<void> {
    const user = await this.usersService.findOneBy({
      where: [{ id: usernameOrUUID }, { username: usernameOrUUID }],
    });

    if (!user.cape) throw new NotFoundException();

    await Promise.all([
      this.storageService.removeFile(user.cape.fileName),
      this.capesRepository.remove(user.cape),
    ]);
  }
}
