import { Column, Entity, Generated, OneToOne, PrimaryColumn } from 'typeorm';
import { UserEntity } from '@/core/users/users/entities/user.entity';

@Entity('user_capes')
export class CapeEntity {
  @PrimaryColumn()
  @Generated('increment')
  id: number;

  @Column()
  fileName: string;

  @Column()
  digest: string;

  @OneToOne(() => UserEntity, (user) => user.cape)
  user: UserEntity;
}
