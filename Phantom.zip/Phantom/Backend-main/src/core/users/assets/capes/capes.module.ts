import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CapesController } from '@/core/users/assets/capes/capes.controller';
import { CapesService } from '@/core/users/assets/capes/capes.service';
import { StorageModule } from '@/core/storage/storage.module';
import { UsersModule } from '@/core/users/users/users.module';
import { CapeEntity } from '@/core/users/assets/capes/entities/cape.entity';

@Module({
  imports: [TypeOrmModule.forFeature([CapeEntity]), StorageModule, UsersModule],
  controllers: [CapesController],
  providers: [CapesService],
  exports: [CapesService, TypeOrmModule],
})
export class CapesModule {}
