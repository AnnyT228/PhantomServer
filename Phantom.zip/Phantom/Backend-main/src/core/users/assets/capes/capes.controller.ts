import {
  Controller,
  Delete,
  Get,
  Header,
  Param,
  Patch,
  StreamableFile,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { CapesService } from '@/core/users/assets/capes/capes.service';
import { AuthGuard } from '@/core/auth/auth/guards/auth-guard.decorator';
import { FileHandler } from '@common/other/file-handler';
import {
  CurrentUser,
  ICurrentUser,
} from '@/core/users/users/decorators/current-user.decorator';
import { FileValidationPipe } from '@common/pipes/file-validation.pipe';
import { Permissions } from '@/core/users/roles/permissions/decorators/permissions.decorator';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';

@ApiTags('assets')
@Controller('users/assets')
export class CapesController {
  constructor(private readonly capesService: CapesService) {}

  @Get(':username/cape')
  @Header('Content-Type', 'image/png')
  streamCapeByUsername(
    @Param('username') username: string,
  ): Promise<StreamableFile> {
    return this.capesService.streamCapeByUsername(username);
  }

  @AuthGuard()
  @Patch('@me/cape')
  @UseInterceptors(FileHandler)
  changeCapeMe(
    @CurrentUser() user: ICurrentUser,
    @UploadedFile(new FileValidationPipe({ maxSizeInMiB: 0.5 }))
    file: Express.Multer.File,
  ): Promise<void> {
    return this.capesService.changeCape(user.userUUID, file);
  }

  @Permissions([Permission.AssetsApi])
  @Patch(':username/cape')
  @UseInterceptors(FileHandler)
  changeCape(
    @Param('username') username: string,
    @UploadedFile(new FileValidationPipe({ maxSizeInMiB: 0.5 }))
    file: Express.Multer.File,
  ): Promise<void> {
    return this.capesService.changeCape(username, file);
  }

  @AuthGuard()
  @Delete('@me/cape')
  removeCapeMe(@CurrentUser() user: ICurrentUser): Promise<void> {
    return this.capesService.removeCape(user.userUUID);
  }

  @Permissions([Permission.AssetsApi])
  @Delete(':username/cape')
  removeCape(@Param('username') username: string): Promise<void> {
    return this.capesService.removeCape(username);
  }
}
