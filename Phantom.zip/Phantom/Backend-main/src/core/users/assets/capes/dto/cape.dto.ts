import { Exclude, Expose } from 'class-transformer';
import { CapeEntity } from '@/core/users/assets/capes/entities/cape.entity';
import { StorageService } from '@/core/storage/storage.service';

@Exclude()
export class CapeDto {
  @Expose()
  url: string;

  @Expose()
  digest: string;

  constructor(capeEntity: CapeEntity) {
    Object.assign(this, capeEntity);

    this.url = StorageService.getInstance
      .getFileUrl(capeEntity.fileName)
      .toString();
  }
}
