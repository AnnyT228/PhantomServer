import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { JwtModule } from '@nestjs/jwt';
import { APP_GUARD } from '@nestjs/core';
import { CacheModule } from '@nestjs/cache-manager';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { typeormModuleConfig } from '@common/configs/typeorm-module.config';
import { RequestsLoggerMiddleware } from '@common/logger/requests-logger.middleware';
import { RolesGuard } from '@/core/users/roles/roles/guards/roles.guard';
import { UserAuthGuard } from '@/core/auth/auth/guards/user-auth.guard';
import { StorageModule } from '@/core/storage/storage.module';
import { AuthMainModule } from '@/core/auth/auth-main.module';
import { ServersMainModule } from '@/core/servers/servers-main.module';
import { cacheModuleConfig } from '@common/configs/redis.config';
import { EmailsModule } from '@/core/emails/emails.module';
import { WidgetsModule } from '@/core/wigdets/widgets-core/widgets.module';
import { NewsMainModule } from '@/core/news/news-main.module';
import { throttlerModuleConfig } from '@common/configs/throttler-module.config';
import { jwtModuleConfig } from '@common/configs/jwt-module.config';
import { UsersMainModule } from '@/core/users/users-main.module';
import { AppController } from '@/core/app.controller';

@Module({
  imports: [
    TypeOrmModule.forRoot(typeormModuleConfig),
    JwtModule.register(jwtModuleConfig),
    CacheModule.registerAsync(cacheModuleConfig),
    ThrottlerModule.forRoot([throttlerModuleConfig]),
    AuthMainModule,
    UsersMainModule,
    ServersMainModule,
    WidgetsModule,
    EmailsModule,
    StorageModule,
    NewsMainModule,
  ],
  controllers: [AppController],
  providers: [
    {
      provide: APP_GUARD,
      useClass: UserAuthGuard,
    },
    // {
    //   provide: APP_GUARD,
    //   useClass: PermissionGuard,
    // },
    {
      provide: APP_GUARD,
      useClass: RolesGuard,
    },
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(RequestsLoggerMiddleware).forRoutes('*');
  }
}
