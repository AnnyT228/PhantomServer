import { HttpStatus, Inject, Injectable } from '@nestjs/common';
import { FindOneOptions } from 'typeorm';
import { compare } from 'bcrypt';
import { JwtService } from '@nestjs/jwt';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import ms from 'ms';
import { TokenExpiredError } from 'jsonwebtoken';
import { UserEntity } from '@/core/users/users/entities/user.entity';
import { GravitAuthorizeDto } from '@/core/auth/gravit/dto/input/gravit-authorize.dto';
import { ApiException } from '@common/api-exceptions/api-exception.error';
import { TokensService } from '@/core/auth/tokens/tokens/tokens.service';
import { GravitJoinServerDto } from '@/core/auth/gravit/dto/input/gravit-join-server.dto';
import { GravitCheckServerDto } from '@/core/auth/gravit/dto/input/gravit-check-server.dto';
import { GravitUserDto } from '@/core/auth/gravit/dto/gravit-user.dto';
import { GravitUserSessionDto } from '@/core/auth/gravit/dto/gravit-user-session.dto';
import { GetJwtPayload } from '@/core/auth/tokens/tokens/dto/jwt-payload.dto';
import { UsersService } from '@/core/users/users/users.service';
import { SessionsService } from '@/core/auth/tokens/sessions/sessions.service';
import { SessionAgent } from '@/core/auth/tokens/sessions/enums/session-agent.enum';
import { Exceptions } from '@common/api-exceptions/exceptions.namespace';

@Injectable()
export class GravitService {
  constructor(
    private readonly tokensService: TokensService,
    private readonly usersService: UsersService,
    private readonly sessionsService: SessionsService,
    private readonly jwtService: JwtService,
    @Inject(CACHE_MANAGER)
    private readonly cacheManager: Cache,
  ) {}

  private async validateToken(
    token: string,
    checkInDatabase: boolean = false,
  ): Promise<GetJwtPayload> {
    const validatedToken = await this.jwtService
      .verifyAsync<GetJwtPayload>(token)
      .catch((e) => {
        if (e instanceof TokenExpiredError) {
          throw new ApiException(
            HttpStatus.FORBIDDEN,
            'GravitExceptions',
            Exceptions.GravitExceptions.TokenExpire,
          );
        }

        throw new ApiException(
          HttpStatus.UNAUTHORIZED,
          'GravitExceptions',
          Exceptions.GravitExceptions.InvalidToken,
        );
      });

    if (checkInDatabase /* || validatedToken.exp < Date.now() / 1000 */) {
      await this.sessionsService
        .findOneBy({
          where: { id: validatedToken?.id, userUUID: validatedToken?.user },
        })
        .catch(() => {
          throw new ApiException(
            HttpStatus.UNAUTHORIZED,
            'GravitExceptions',
            Exceptions.GravitExceptions.TokenExpire,
          );
        });
    }

    return validatedToken;
  }

  private async findUserBy(
    options: FindOneOptions<UserEntity>,
  ): Promise<UserEntity> {
    return await this.usersService.findOneBy(options).catch(() => {
      throw new ApiException(
        HttpStatus.NOT_FOUND,
        'GravitExceptions',
        Exceptions.GravitExceptions.UserNotFound,
      );
    });
  }

  async getUserByUsername(username: string): Promise<GravitUserDto> {
    const user = await this.findUserBy({ where: { username: username } });

    return new GravitUserDto(user);
  }

  async getUserByUUID(userUUID: string): Promise<GravitUserDto> {
    const user = await this.findUserBy({ where: { id: userUUID } });

    return new GravitUserDto(user);
  }

  async getUserByToken(token: string): Promise<GravitUserSessionDto> {
    const decodedToken = await this.validateToken(token, false);

    const user = await this.findUserBy({ where: { id: decodedToken.user } });

    return new GravitUserSessionDto(user, token, undefined);
  }

  async refresh(oldRefreshToken: string): Promise<GravitUserSessionDto> {
    const decodedToken = await this.validateToken(oldRefreshToken, true);

    const user = await this.findUserBy({ where: { id: decodedToken.user } });

    const { accessToken, refreshToken } =
      await this.tokensService.generateAccessViaRefresh(
        oldRefreshToken,
        SessionAgent.Launcher,
      );

    await this.cacheManager.set(
      user.username.concat('-token'),
      accessToken,
      ms('24h'),
    );

    return new GravitUserSessionDto(user, accessToken, refreshToken);
  }

  async authorize(
    authorizeDto: GravitAuthorizeDto,
  ): Promise<GravitUserSessionDto> {
    const user = await this.findUserBy({
      where: { username: authorizeDto.login },
    });

    if (!(await compare(authorizeDto.password, user.password))) {
      throw new ApiException(
        HttpStatus.FORBIDDEN,
        'GravitExceptions',
        Exceptions.GravitExceptions.WrongPassword,
      );
    }

    const { accessToken, refreshToken } =
      await this.tokensService.getTokensPair(user.id, SessionAgent.Launcher);

    await this.cacheManager.set(
      user.username.concat('-token'),
      accessToken,
      ms('24h'),
    );

    return new GravitUserSessionDto(user, accessToken, refreshToken);
  }

  async joinServer(joinServerDto: GravitJoinServerDto): Promise<void> {
    await this.validateToken(joinServerDto.accessToken, true);

    await this.cacheManager.set(
      joinServerDto.username.concat('-serverId'),
      joinServerDto.serverId,
      ms('24h'),
    );
  }

  async checkServer(
    checkServerDto: GravitCheckServerDto,
  ): Promise<GravitUserDto> {
    const user = await this.findUserBy({
      where: {
        username: checkServerDto.username,
      },
    });

    if (!user) {
      throw new ApiException(
        HttpStatus.NOT_FOUND,
        'GravitExceptions',
        Exceptions.GravitExceptions.UserNotFound,
      );
    }

    const serverId = await this.cacheManager.get(
      user.username.concat('-serverId'),
    );

    if (serverId !== checkServerDto.serverId) {
      throw new ApiException(
        HttpStatus.FORBIDDEN,
        'GravitExceptions',
        Exceptions.GravitExceptions.InvalidToken,
      );
    }

    return new GravitUserDto(user);
  }

  deleteSession(sessionId: string): void {
    this.sessionsService
      .removeOneBy({
        where: {
          id: sessionId,
          agent: SessionAgent.Launcher,
        },
      })
      .catch(() => {});
  }
}
