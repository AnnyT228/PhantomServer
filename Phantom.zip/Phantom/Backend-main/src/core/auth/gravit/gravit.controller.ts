import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { GravitService } from '@/core/auth/gravit/gravit.service';
import { GravitAuthorizeDto } from '@/core/auth/gravit/dto/input/gravit-authorize.dto';
import { GravitJoinServerDto } from '@/core/auth/gravit/dto/input/gravit-join-server.dto';
import { GravitCheckServerDto } from '@/core/auth/gravit/dto/input/gravit-check-server.dto';
import { Permissions } from '@/core/users/roles/permissions/decorators/permissions.decorator';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';
import { ValidatedBody } from '@common/validators/validated-body.decorator';
import { GravitUserDto } from '@/core/auth/gravit/dto/gravit-user.dto';
import { GravitUserSessionDto } from '@/core/auth/gravit/dto/gravit-user-session.dto';

@ApiTags('auth/gravit')
@Permissions([Permission.GravitApi])
@Controller('auth/gravit')
export class GravitController {
  constructor(private readonly gravitService: GravitService) {}

  @Get('getUserByUsername/:username')
  getUserByUsername(
    @Param('username') username: string,
  ): Promise<GravitUserDto> {
    return this.gravitService.getUserByUsername(username);
  }

  @Get('getUserByUuid/:uuid')
  getUserByUUID(@Param('uuid') uuid: string): Promise<GravitUserDto> {
    return this.gravitService.getUserByUUID(uuid);
  }

  @Post('getUserByToken')
  getUserByToken(
    @ValidatedBody('accessToken') accessToken: string,
  ): Promise<GravitUserSessionDto> {
    return this.gravitService.getUserByToken(accessToken);
  }

  @Post('refresh')
  refresh(
    @ValidatedBody('refreshToken') refreshToken: string,
  ): Promise<GravitUserSessionDto> {
    return this.gravitService.refresh(refreshToken);
  }

  @Post('authorize')
  authorize(
    @Body() authorizeDto: GravitAuthorizeDto,
  ): Promise<GravitUserSessionDto> {
    return this.gravitService.authorize(authorizeDto);
  }

  @Post('joinServer')
  joinServer(@Body() joinServerDto: GravitJoinServerDto): Promise<void> {
    return this.gravitService.joinServer(joinServerDto);
  }

  @Post('checkServer')
  checkServer(
    @Body() checkServerDto: GravitCheckServerDto,
  ): Promise<GravitUserDto> {
    return this.gravitService.checkServer(checkServerDto);
  }

  @Post('deleteSession')
  deleteSession(@ValidatedBody('sessionId') sessionId: string): void {
    return this.gravitService.deleteSession(sessionId);
  }
}
