import { Exclude, Expose } from 'class-transformer';
import { UserEntity } from '@/core/users/users/entities/user.entity';
import { RoleMetadata } from '@/core/users/roles/roles/dto/role-metadata.dto';
import { AssetsDto } from '@/core/users/assets/dto/assets.dto';

@Exclude()
export class GravitUserDto {
  @Expose()
  username: string;

  @Expose()
  uuid: string;

  @Expose()
  roles: string[];

  @Expose()
  permissions: string[];

  @Expose()
  assets: AssetsDto;

  constructor(user: UserEntity) {
    Object.assign(this, user);

    this.uuid = user.id;
    this.assets = new AssetsDto(user.skin, user.cape);

    const roleMetadata = new RoleMetadata(user.roles);
    this.roles = roleMetadata.roles;
    this.permissions = roleMetadata.perms;
  }
}
