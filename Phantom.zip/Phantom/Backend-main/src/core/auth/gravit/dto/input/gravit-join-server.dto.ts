import { IsNotEmpty, IsString } from 'class-validator';
import { StringWithoutSpaces } from '@common/validators/string-without-spaces.decorator';

export class GravitJoinServerDto {
  @IsNotEmpty()
  @IsString()
  @StringWithoutSpaces()
  username: string;

  @IsNotEmpty()
  @IsString()
  @StringWithoutSpaces()
  accessToken: string;

  @IsNotEmpty()
  @IsString()
  @StringWithoutSpaces()
  serverId: string;
}
