import { Exclude, Expose } from 'class-transformer';
import { GravitUserSessionDto } from '@/core/auth/gravit/dto/gravit-user-session.dto';
import { UserEntity } from '@/core/users/users/entities/user.entity';

@Exclude()
export class GravitAuthReportDto {
  @Expose()
  minecraftAccessToken: string;

  @Expose()
  oauthAccessToken: string;

  @Expose()
  oauthRefreshToken: string;

  @Expose()
  oauthExpire: number;

  @Expose()
  session: GravitUserSessionDto;

  constructor(
    partial: UserEntity,
    accessToken: string,
    refreshToken: string,
    accessTokenExpire: number,
    minecraftAccess: boolean,
  ) {
    this.session = new GravitUserSessionDto(partial, accessToken, refreshToken) ?? undefined;
    this.oauthAccessToken = accessToken;
    this.oauthRefreshToken = refreshToken;
    this.oauthExpire = accessTokenExpire;
    this.minecraftAccessToken = minecraftAccess ? this.oauthAccessToken : undefined;
  }
}
