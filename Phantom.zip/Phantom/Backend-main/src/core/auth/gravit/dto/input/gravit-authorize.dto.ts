import { IsNotEmpty, IsString } from 'class-validator';
import { StringWithoutSpaces } from '@common/validators/string-without-spaces.decorator';

export class GravitAuthorizeDto {
  @IsNotEmpty()
  @IsString()
  @StringWithoutSpaces()
  login: string;

  @IsNotEmpty()
  @IsString()
  password: string;
}
