import {
  IsNotEmpty,
  IsNotEmptyObject,
  IsObject,
  IsString,
} from 'class-validator';
import { StringWithoutSpaces } from '@common/validators/string-without-spaces.decorator';

export class GravitRefreshDto {
  @IsNotEmpty()
  @IsString()
  @StringWithoutSpaces()
  refreshToken: string;

  @IsObject()
  @IsNotEmptyObject()
  context: {
    ip: string;
  };
}
