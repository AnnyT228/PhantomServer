import { IsNotEmpty, IsString } from 'class-validator';
import { StringWithoutSpaces } from '@common/validators/string-without-spaces.decorator';

export class GravitCheckServerDto {
  @IsNotEmpty()
  @IsString()
  @StringWithoutSpaces()
  username: string;

  @IsNotEmpty()
  @IsString()
  @StringWithoutSpaces()
  serverId: string;
}
