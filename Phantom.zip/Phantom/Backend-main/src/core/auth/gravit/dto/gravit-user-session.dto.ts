import { Exclude, Expose } from 'class-transformer';
import { v4 as uuidv4 } from 'uuid';
import { GravitUserDto } from '@/core/auth/gravit/dto/gravit-user.dto';
import { UserEntity } from '@/core/users/users/entities/user.entity';

@Exclude()
export class GravitUserSessionDto {
  @Expose()
  id: string;

  @Expose()
  user: GravitUserDto;

  @Expose()
  accessToken: string;

  @Expose()
  refreshToken: string;

  @Expose()
  expiresIn: number;

  constructor(user: UserEntity, accessToken: string, refreshToken: string) {
    this.id = uuidv4();
    this.user = new GravitUserDto(user);
    this.accessToken = accessToken;
    this.refreshToken = refreshToken;
    this.expiresIn = 900000;
  }
}
