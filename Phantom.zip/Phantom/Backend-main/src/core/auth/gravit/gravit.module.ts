import { Module } from '@nestjs/common';
import { UsersModule } from '@/core/users/users/users.module';
import { TokensModule } from '@/core/auth/tokens/tokens/tokens.module';
import { SessionsModule } from '@/core/auth/tokens/sessions/sessions.module';
import { GravitController } from './gravit.controller';
import { GravitService } from './gravit.service';

@Module({
  imports: [UsersModule, TokensModule, SessionsModule],
  providers: [GravitService],
  controllers: [GravitController],
  exports: [GravitService],
})
export class GravitModule {}
