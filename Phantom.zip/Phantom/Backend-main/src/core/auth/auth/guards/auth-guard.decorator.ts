import { Reflector } from '@nestjs/core';

// export const AUTH_GUARD = 'AUTH_GUARD';
// export const AuthGuard = (): ReturnType<typeof AuthGuard> =>
//   SetMetadata(AUTH_GUARD, true);

export const AuthGuard = Reflector.createDecorator<true>();
