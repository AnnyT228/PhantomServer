import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AuthTokensHelper } from '@/core/auth/tokens/tokens/auth-tokens-helper.service';
import { TokensService } from '@/core/auth/tokens/tokens/tokens.service';
import { AuthGuard } from '@/core/auth/auth/guards/auth-guard.decorator';
import { Permissions } from '@/core/users/roles/permissions/decorators/permissions.decorator';

@Injectable()
export class UserAuthGuard implements CanActivate {
  constructor(
    private readonly authTokensHelper: AuthTokensHelper,
    private readonly tokensService: TokensService,
    private readonly reflector: Reflector,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const authGuard = this.reflector.getAllAndOverride(AuthGuard, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!authGuard) return true;

    const requiredPerms = this.reflector.getAllAndOverride(Permissions, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (requiredPerms) return true;

    const request = context.switchToHttp().getRequest();
    const { token, type } = {
      ...this.authTokensHelper.extractTokenFromHeader(request),
    };

    if (!token || type === 'Api-Key') throw new UnauthorizedException();

    request['user'] = await this.tokensService.validateToken(token);

    return true;
  }
}
