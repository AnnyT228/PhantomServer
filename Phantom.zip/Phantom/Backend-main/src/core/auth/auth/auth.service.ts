import { HttpStatus, Injectable } from '@nestjs/common';
import { compare } from 'bcrypt';
import { Response } from 'express';
import { UsersService } from '@/core/users/users/users.service';
import { AuthenticatedDto } from '@/core/auth/auth/dto/auth.dto';
import { TokensService } from '@/core/auth/tokens/tokens/tokens.service';
import { EmailsService } from '@/core/emails/emails.service';
import { ApiException } from '@common/api-exceptions/api-exception.error';
import { refreshCookiesSettings } from '@common/other/refresh-cookies.settings';
import { RegisterDto } from '@/core/auth/auth/dto/register.dto';
import { LoginDto } from '@/core/auth/auth/dto/login.dto';
import { SessionAgent } from '@/core/auth/tokens/sessions/enums/session-agent.enum';
import { Exceptions } from '@common/api-exceptions/exceptions.namespace';

@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly emailService: EmailsService,
    private readonly tokensService: TokensService,
  ) {}

  async register(registerDto: RegisterDto): Promise<void> {
    const user = await this.usersService.createUser({
      ...registerDto,
    });

    this.emailService.sendActivate(user.email);
  }

  async login(
    loginDto: LoginDto,
    response: Response,
  ): Promise<AuthenticatedDto> {
    const user = await this.usersService.findOneBy({
      where: [
        { username: loginDto.usernameOrEmail },
        { email: loginDto.usernameOrEmail },
      ],
    });

    if (!(await compare(loginDto.password, user.password))) {
      throw new ApiException(
        HttpStatus.BAD_REQUEST,
        'UsersExceptions',
        Exceptions.UsersExceptions.WrongPassword,
      );
    }

    const { accessToken, refreshToken } =
      await this.tokensService.getTokensPair(user.id, SessionAgent.Site);

    response.cookie('refreshToken', refreshToken, refreshCookiesSettings);

    return new AuthenticatedDto(user, accessToken);
  }

  async logout(refreshToken: string, response: Response): Promise<void> {
    await this.tokensService.revokeRefreshToken(refreshToken);
    response.clearCookie('refreshToken');
  }

  async refresh(
    refreshToken: string,
    response: Response,
  ): Promise<{ accessToken: string }> {
    const tokens = await this.tokensService.generateAccessViaRefresh(
      refreshToken,
      SessionAgent.Site,
    );

    response.cookie(
      'refreshToken',
      tokens.refreshToken,
      refreshCookiesSettings,
    );

    return {
      accessToken: tokens.accessToken,
    };
  }
}
