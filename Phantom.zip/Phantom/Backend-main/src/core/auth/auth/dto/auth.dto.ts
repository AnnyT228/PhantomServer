import { Exclude, Expose, instanceToPlain } from 'class-transformer';
import { UserEntity } from '@/core/users/users/entities/user.entity';
import { UserDto } from '@/core/users/users/dto/user.dto';

@Exclude()
export class AuthenticatedDto {
  @Expose()
  user: UserDto;

  @Expose()
  accessToken: string;

  constructor(partial: Partial<UserEntity>, accessToken: string) {
    this.user = instanceToPlain(new UserDto(partial)) as UserDto;
    this.accessToken = accessToken;
  }
}
