import { IsNotEmpty, IsString, Length } from 'class-validator';
import { StringWithoutSpaces } from '@common/validators/string-without-spaces.decorator';

export class LoginDto {
  @IsNotEmpty()
  @IsString()
  @StringWithoutSpaces()
  usernameOrEmail: string;

  @IsNotEmpty()
  @Length(6, 32)
  @IsString()
  @StringWithoutSpaces()
  password: string;
}
