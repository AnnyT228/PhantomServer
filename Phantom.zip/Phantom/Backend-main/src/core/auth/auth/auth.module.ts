import { Module } from '@nestjs/common';
import { AuthController } from '@/core/auth/auth/auth.controller';
import { EmailsModule } from '@/core/emails/emails.module';
import { UsersModule } from '@/core/users/users/users.module';
import { TokensModule } from '@/core/auth/tokens/tokens/tokens.module';
import { AuthService } from './auth.service';

@Module({
  imports: [UsersModule, TokensModule, EmailsModule],
  controllers: [AuthController],
  providers: [AuthService],
  exports: [AuthService],
})
export class AuthModule {}
