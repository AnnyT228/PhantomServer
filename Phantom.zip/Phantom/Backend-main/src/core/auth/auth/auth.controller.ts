import { Body, Controller, Post, Res } from '@nestjs/common';
import { Response } from 'express';
import { ApiTags } from '@nestjs/swagger';
import { Cookies } from '@common/other/cookies.decorator';
import { RegisterDto } from '@/core/auth/auth/dto/register.dto';
import { LoginDto } from '@/core/auth/auth/dto/login.dto';
import { AuthenticatedDto } from '@/core/auth/auth/dto/auth.dto';
import { AuthService } from './auth.service';

@ApiTags('auth')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('register')
  register(@Body() registerDto: RegisterDto): Promise<void> {
    return this.authService.register(registerDto);
  }

  @Post('login')
  login(
    @Body() loginDto: LoginDto,
    @Res({ passthrough: true }) response: Response,
  ): Promise<AuthenticatedDto> {
    return this.authService.login(loginDto, response);
  }

  @Post('refresh')
  refresh(
    @Cookies('refreshToken') refreshToken: string,
    @Res({ passthrough: true }) response: Response,
  ): Promise<{ accessToken: string }> {
    return this.authService.refresh(refreshToken, response);
  }

  @Post('logout')
  logout(
    @Cookies('refreshToken') refreshToken: string,
    @Res({ passthrough: true }) response: Response,
  ): Promise<void> {
    return this.authService.logout(refreshToken, response);
  }
}
