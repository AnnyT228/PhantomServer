import { Module } from '@nestjs/common';
import { DiscordOauthModule } from '@/core/auth/oauth/discord/discord-oauth.module';

@Module({
  imports: [DiscordOauthModule],
  exports: [DiscordOauthModule],
})
export class OauthModule {}
