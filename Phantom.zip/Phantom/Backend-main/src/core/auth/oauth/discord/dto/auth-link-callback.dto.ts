import { IsNotEmpty, IsString } from 'class-validator';

export class AuthLinkCallbackDto {
  @IsNotEmpty()
  @IsString()
  code: string;

  @IsNotEmpty()
  @IsString()
  state: string;
}
