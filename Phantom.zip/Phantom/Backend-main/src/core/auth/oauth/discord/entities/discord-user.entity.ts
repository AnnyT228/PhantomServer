import { Entity, OneToOne, PrimaryColumn } from 'typeorm';
import { UserEntity } from '@/core/users/users/entities/user.entity';

@Entity()
export class DiscordUserEntity {
  @PrimaryColumn()
  id: string;

  @OneToOne(() => UserEntity, (user) => user.discord)
  user: UserEntity;
}
