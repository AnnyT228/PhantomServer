import { Controller, Get, Query, Res } from '@nestjs/common';
import { Response } from 'express';
import { ApiTags } from '@nestjs/swagger';
import { DiscordOauthService } from '@/core/auth/oauth/discord/discord-oauth.service';
import { AuthLinkCallbackDto } from '@/core/auth/oauth/discord/dto/auth-link-callback.dto';
import { AuthenticatedDto } from '@/core/auth/auth/dto/auth.dto';

@ApiTags('auth/oauth/discord')
@Controller('auth/oauth/discord')
export class DiscordOauthController {
  constructor(private readonly discordService: DiscordOauthService) {}

  @Get('link')
  generateAuthLink(): Promise<{ url: string }> {
    return this.discordService.generateAuthLink();
  }

  @Get('link/handler')
  async authLinkCallback(
    @Query() authLinkCallback: AuthLinkCallbackDto,
    @Res({ passthrough: true }) response: Response,
  ): Promise<AuthenticatedDto> {
    return this.discordService.authLinkCallback(authLinkCallback, response);
  }
}
