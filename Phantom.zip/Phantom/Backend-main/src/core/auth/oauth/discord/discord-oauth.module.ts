import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HttpModule } from '@nestjs/axios';
import { DiscordOauthService } from '@/core/auth/oauth/discord/discord-oauth.service';
import { DiscordOauthController } from '@/core/auth/oauth/discord/discord-oauth.controller';
import { DiscordUserEntity } from '@/core/auth/oauth/discord/entities/discord-user.entity';
import { UsersModule } from '@/core/users/users/users.module';
import { TokensModule } from '@/core/auth/tokens/tokens/tokens.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([DiscordUserEntity]),
    UsersModule,
    TokensModule,
    HttpModule,
  ],
  controllers: [DiscordOauthController],
  providers: [DiscordOauthService],
  exports: [DiscordOauthService],
})
export class DiscordOauthModule {}
