import {
  BadRequestException,
  HttpStatus,
  Inject,
  Injectable,
} from '@nestjs/common';
import {
  APIUser,
  OAuth2Routes,
  OAuth2Scopes,
  RESTGetAPICurrentUserResult,
  RESTOAuth2AuthorizationQuery,
  RESTPostOAuth2AccessTokenResult,
  RESTPostOAuth2AccessTokenURLEncodedData,
  Routes,
} from 'discord-api-types/v10';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { v4 as uuidv4 } from 'uuid';
import { REST } from '@discordjs/rest';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
import { Response } from 'express';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import ms from 'ms';
import { Cache } from 'cache-manager';
import { envConfig } from '@common/configs/env.config';
import { AuthLinkCallbackDto } from '@/core/auth/oauth/discord/dto/auth-link-callback.dto';
import { UsersService } from '@/core/users/users/users.service';
import { TokensService } from '@/core/auth/tokens/tokens/tokens.service';
import { AuthenticatedDto } from '@/core/auth/auth/dto/auth.dto';
import { DiscordUserEntity } from '@/core/auth/oauth/discord/entities/discord-user.entity';
import { ApiException } from '@common/api-exceptions/api-exception.error';
import { refreshCookiesSettings } from '@common/other/refresh-cookies.settings';
import { SessionAgent } from '@/core/auth/tokens/sessions/enums/session-agent.enum';
import { UserEntity } from '@/core/users/users/entities/user.entity';
import { Exceptions } from '@common/api-exceptions/exceptions.namespace';

@Injectable()
export class DiscordOauthService {
  private readonly rest = new REST({
    authPrefix: 'Bearer',
    version: '10',
    retries: 3,
  });

  constructor(
    @Inject(CACHE_MANAGER)
    private readonly cacheManager: Cache,
    @InjectRepository(DiscordUserEntity)
    private readonly discordUsersRepository: Repository<DiscordUserEntity>,
    private readonly usersService: UsersService,
    private readonly tokensService: TokensService,
    private readonly httpService: HttpService,
  ) {}

  async generateAuthLink(): Promise<{ url: string }> {
    const { token, randomKey } = this.generateStateToken();

    const query: RESTOAuth2AuthorizationQuery = {
      client_id: envConfig.discord.clientId,
      response_type: 'code',
      scope: [OAuth2Scopes.Identify, OAuth2Scopes.Email].join(' '),
      state: randomKey + '/' + token,
      redirect_uri: envConfig.discord.redirectUrl.href,
    };

    const authorizeUrl = new URL(OAuth2Routes.authorizationURL);
    authorizeUrl.search = new URLSearchParams({ ...query }).toString();

    return { url: authorizeUrl.href };
  }

  async authLinkCallback(
    authLinkCallback: AuthLinkCallbackDto,
    response: Response,
  ): Promise<AuthenticatedDto> {
    const [key, state] = authLinkCallback.state.split('/') as [string, string];
    const existState = await this.cacheManager.get(key);

    if (!existState || state !== existState) throw new BadRequestException();

    this.cacheManager.del(key);

    const userAccess = await this.getUserAccessToken(authLinkCallback.code);
    const userData = await this.getDiscordUser(userAccess.access_token);

    let userByDiscordData = (await this.usersService
      .findOneBy({
        where: [
          { discord: { id: userData.id } },
          { username: userData.username },
          { email: userData.email },
        ],
      })
      .catch(() => {})) as UserEntity;

    if (userByDiscordData && userByDiscordData.discord?.id !== userData.id) {
      throw new ApiException(
        HttpStatus.BAD_REQUEST,
        'UsersExceptions',
        Exceptions.UsersExceptions.UserExist,
      );
    }

    if (!userByDiscordData) {
      userByDiscordData = await this.usersService.createUser({
        username: userData.username.replaceAll(' ', ''),
        email: userData.email,
        password: uuidv4(),
        activated: true,
      });

      await this.usersService.updateOneBy(userByDiscordData, {
        discord: await this.discordUsersRepository.save({
          id: userData.id,
        }),
      });
    }

    if (userByDiscordData.email !== userData.email) {
      await this.usersService.updateOneBy(userByDiscordData, {
        email: userData.email,
      });
    }

    const { accessToken, refreshToken } =
      await this.tokensService.getTokensPair(
        userByDiscordData.id,
        SessionAgent.DiscordOAuth,
      );

    response.cookie('refreshToken', refreshToken, refreshCookiesSettings);

    return new AuthenticatedDto(userByDiscordData, accessToken);
  }

  private async getUserAccessToken(
    code: string,
  ): Promise<RESTPostOAuth2AccessTokenResult> {
    const data: RESTPostOAuth2AccessTokenURLEncodedData = {
      client_id: envConfig.discord.clientId,
      client_secret: envConfig.discord.clientSecret,
      grant_type: 'authorization_code',
      code: code,
      redirect_uri: envConfig.discord.redirectUrl.href,
    };

    const request = this.httpService.post<RESTPostOAuth2AccessTokenResult>(
      OAuth2Routes.tokenURL,
      data,
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept-Encoding': 'gzip,deflate,compress',
        },
      },
    );

    return (await firstValueFrom(request)).data;
  }

  private async getDiscordUser(
    accessToken: string,
  ): Promise<Pick<APIUser, 'username' | 'email' | 'id'>> {
    const rest = this.rest.setToken(accessToken);

    return (await rest.get(Routes.user())) as RESTGetAPICurrentUserResult;
  }

  private generateStateToken(): { token: string; randomKey: string } {
    const token = uuidv4() + uuidv4();
    const randomKey = uuidv4();
    this.cacheManager.set(randomKey, token, ms('15m'));

    return { token, randomKey };
  }
}
