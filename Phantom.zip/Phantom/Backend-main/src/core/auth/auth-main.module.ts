import { Module } from '@nestjs/common';
import { AuthModule } from '@/core/auth/auth/auth.module';
import { GravitModule } from '@/core/auth/gravit/gravit.module';
import { OauthModule } from '@/core/auth/oauth/oauth.module';
import { TokensMainModule } from '@/core/auth/tokens/tokens-main.module';

@Module({
  imports: [AuthModule, GravitModule, OauthModule, TokensMainModule],
  exports: [AuthModule, GravitModule, OauthModule, TokensMainModule],
})
export class AuthMainModule {}
