import { Module } from '@nestjs/common';
import { TokensModule } from '@/core/auth/tokens/tokens/tokens.module';
import { SessionsModule } from '@/core/auth/tokens/sessions/sessions.module';
import { ApiKeysModule } from '@/core/auth/tokens/api-keys/api-keys.module';

@Module({
  imports: [TokensModule, SessionsModule, ApiKeysModule],
  exports: [TokensModule, SessionsModule, ApiKeysModule],
})
export class TokensMainModule {}
