import { ArrayNotEmpty, IsArray, IsEnum } from 'class-validator';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';

export class CreateApiKeyDto {
  @IsArray()
  @ArrayNotEmpty()
  @IsEnum(Permission, { each: true })
  permissions: Permission[];
}
