import { ForbiddenException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { compare, hash } from 'bcrypt';
import { v4 as uuidv4 } from 'uuid';
import { CreateApiKeyDto } from '@/core/auth/tokens/api-keys/dto/create-api-key.dto';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';
import { ApiKeyEntity } from '@/core/auth/tokens/api-keys/entities/api-key.entity';
import { PermissionsService } from '@/core/users/roles/permissions/permissions.service';
import { ChangeApiKeyDto } from '@/core/auth/tokens/api-keys/dto/change-api-key.dto';
import { BaseEntityService } from '@common/other/abstract-base-entity.service';
import { ApiKeyDto } from '@/core/auth/tokens/api-keys/dto/api-key.dto';

@Injectable()
export class ApiKeysService extends BaseEntityService<ApiKeyEntity, ApiKeyDto> {
  constructor(
    @InjectRepository(ApiKeyEntity)
    private readonly apiKeysRepository: Repository<ApiKeyEntity>,
    private readonly permissionsUtils: PermissionsService,
  ) {
    super(apiKeysRepository, ApiKeyDto);
  }

  async generateApiKey(
    createApiKeyDto: CreateApiKeyDto,
  ): Promise<{ key: string }> {
    const apiKey = uuidv4();

    const newToken = await this.apiKeysRepository.save({
      token: await hash(apiKey, 10),
      permissions: createApiKeyDto.permissions,
    });

    return { key: `${newToken.id}:${apiKey}` };
  }

  async validateApiKey(
    token: string,
    permissions: Permission[],
  ): Promise<boolean> {
    const [id, apiKey] = token.split(':');
    const apiKeyEntity = await this.findOneBy({
      where: { id: id },
    });

    if (!(await compare(apiKey, apiKeyEntity.token))) {
      throw new ForbiddenException();
    }

    return this.permissionsUtils.matchPermissions(
      apiKeyEntity.permissions,
      permissions,
    );
  }

  async changeApiKey(
    tokenId: string,
    changeApiKeyDto: ChangeApiKeyDto,
  ): Promise<void> {
    const apiKey = await this.findOneBy({ where: { id: tokenId } });

    await this.updateOneBy(apiKey, {
      permissions: changeApiKeyDto.permissions,
    });
  }
}
