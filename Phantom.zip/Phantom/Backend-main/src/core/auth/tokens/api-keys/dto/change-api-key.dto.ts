import { CreateApiKeyDto } from '@/core/auth/tokens/api-keys/dto/create-api-key.dto';

export class ChangeApiKeyDto extends CreateApiKeyDto {}
