import { PaginationDto } from '@common/pagination/pagination.dto';

export class GetApiKeysQueryDto extends PaginationDto {}
