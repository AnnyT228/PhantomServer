import { Column, Entity, Generated, PrimaryColumn } from 'typeorm';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';

@Entity('api_keys')
export class ApiKeyEntity {
  @PrimaryColumn()
  @Generated('uuid')
  id: string;

  @Column()
  token: string;

  @Column('simple-array')
  permissions: Permission[];
}
