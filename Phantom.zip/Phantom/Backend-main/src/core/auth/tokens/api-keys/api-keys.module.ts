import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ApiKeyEntity } from '@/core/auth/tokens/api-keys/entities/api-key.entity';
import { ApiKeysService } from '@/core/auth/tokens/api-keys/api-keys.service';
import { ApiKeysController } from '@/core/auth/tokens/api-keys/api-keys.controller';
import { PermissionsService } from '@/core/users/roles/permissions/permissions.service';

@Module({
  imports: [TypeOrmModule.forFeature([ApiKeyEntity])],
  controllers: [ApiKeysController],
  providers: [ApiKeysService, PermissionsService],
  exports: [ApiKeysService, TypeOrmModule],
})
export class ApiKeysModule {}
