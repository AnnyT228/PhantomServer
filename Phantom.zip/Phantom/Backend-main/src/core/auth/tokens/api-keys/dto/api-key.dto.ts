import { Exclude, Expose } from 'class-transformer';
import { ApiKeyEntity } from '@/core/auth/tokens/api-keys/entities/api-key.entity';

@Exclude()
export class ApiKeyDto {
  @Expose()
  id: string;

  @Expose()
  permissions: string[];

  constructor(apiKeyEntity: ApiKeyEntity) {
    Object.assign(this, apiKeyEntity);
  }
}
