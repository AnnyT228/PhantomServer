import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { In } from 'typeorm';
import { CreateApiKeyDto } from '@/core/auth/tokens/api-keys/dto/create-api-key.dto';
import { ApiKeysService } from '@/core/auth/tokens/api-keys/api-keys.service';
import { ChangeApiKeyDto } from '@/core/auth/tokens/api-keys/dto/change-api-key.dto';
import { GetApiKeysQueryDto } from '@/core/auth/tokens/api-keys/dto/get-api-keys-query.dto';
import { ValidatedBody } from '@common/validators/validated-body.decorator';
import { Permissions } from '@/core/users/roles/permissions/decorators/permissions.decorator';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';
import { getPagination } from '@common/pagination/get-pagination';
import { ApiKeyDto } from '@/core/auth/tokens/api-keys/dto/api-key.dto';

@ApiTags('api-keys')
@Permissions([Permission.ApiKeysApi])
@Controller('api-keys')
export class ApiKeysController {
  constructor(private readonly apiKeysService: ApiKeysService) {}

  @Post()
  createApiKey(
    @Body() createApiKeyDto: CreateApiKeyDto,
  ): Promise<{ key: string }> {
    return this.apiKeysService.generateApiKey(createApiKeyDto);
  }

  @Get(':keyId')
  getApiKey(@Param('key') key: string): Promise<ApiKeyDto> {
    return this.apiKeysService.findOneBy(
      { where: { id: key.split(':')[0] } },
      true,
    );
  }

  @Get()
  getAllApiKeys(
    @Query() apiKeysQueryDto: GetApiKeysQueryDto,
  ): Promise<ApiKeyDto[]> {
    return this.apiKeysService.findManyBy(
      {
        ...getPagination(apiKeysQueryDto),
      },
      true,
    );
  }

  @Patch(':keyId')
  changeApiKey(
    @Param('keyId') keyId: string,
    @Body() changeApiKeyDto: ChangeApiKeyDto,
  ): Promise<void> {
    return this.apiKeysService.changeApiKey(keyId, changeApiKeyDto);
  }

  @Delete(':keyId')
  removeByKeyId(@Param('keyId') keyId: string): Promise<void> {
    return this.apiKeysService.removeOneBy({ where: { id: keyId } });
  }

  @Delete()
  removeManyByIds(@ValidatedBody('ids') ids: string[]): Promise<void> {
    return this.apiKeysService.removeManyBy({
      where: { id: In(ids) },
    });
  }
}
