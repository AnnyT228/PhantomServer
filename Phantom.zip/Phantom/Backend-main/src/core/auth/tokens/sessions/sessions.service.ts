import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { SessionEntity } from '@/core/auth/tokens/sessions/entities/session.entity';
import { BaseEntityService } from '@common/other/abstract-base-entity.service';
import { SessionDto } from '@/core/auth/tokens/sessions/dto/session.dto';

@Injectable()
export class SessionsService extends BaseEntityService<
  SessionEntity,
  SessionDto
> {
  constructor(
    @InjectRepository(SessionEntity)
    private readonly sessionsRepository: Repository<SessionEntity>,
  ) {
    super(sessionsRepository, SessionDto);
  }

  async saveSessionEntity(
    createSessionDto: SessionEntity,
  ): Promise<SessionEntity> {
    return await this.sessionsRepository.save(createSessionDto);
  }
}
