import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SessionEntity } from '@/core/auth/tokens/sessions/entities/session.entity';
import { SessionsController } from '@/core/auth/tokens/sessions/sessions.controller';
import { SessionsService } from '@/core/auth/tokens/sessions/sessions.service';

@Module({
  imports: [TypeOrmModule.forFeature([SessionEntity])],
  controllers: [SessionsController],
  providers: [SessionsService],
  exports: [SessionsService, TypeOrmModule],
})
export class SessionsModule {}
