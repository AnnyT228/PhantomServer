import { Exclude, Expose } from 'class-transformer';
import { SessionEntity } from '@/core/auth/tokens/sessions/entities/session.entity';
import { SessionAgent } from '@/core/auth/tokens/sessions/enums/session-agent.enum';

@Exclude()
export class SessionDto {
  @Expose()
  id: string;

  @Expose()
  agent: SessionAgent;

  @Expose()
  expiresAt: Date;

  constructor(sessionEntity: SessionEntity) {
    Object.assign(this, sessionEntity);
  }
}
