import { Controller, Delete, Get, Param, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { AuthGuard } from '@/core/auth/auth/guards/auth-guard.decorator';
import {
  CurrentUser,
  ICurrentUser,
} from '@/core/users/users/decorators/current-user.decorator';
import { Permissions } from '@/core/users/roles/permissions/decorators/permissions.decorator';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';
import { SessionsService } from '@/core/auth/tokens/sessions/sessions.service';
import { GetSessionsQueryDto } from '@/core/auth/tokens/sessions/dto/get-sessions-query.dto';
import { getPagination } from '@common/pagination/get-pagination';
import { SessionDto } from '@/core/auth/tokens/sessions/dto/session.dto';

@ApiTags('sessions')
@Controller('sessions')
export class SessionsController {
  constructor(private readonly sessionsService: SessionsService) {}

  @AuthGuard()
  @Get('@me')
  getAllSessionsMe(
    @CurrentUser() user: ICurrentUser,
    @Query() getSessionsQueryDto: GetSessionsQueryDto,
  ): Promise<SessionDto[]> {
    return this.sessionsService.findManyBy(
      {
        where: { userUUID: user.userUUID, agent: getSessionsQueryDto?.agent },
        ...getPagination(getSessionsQueryDto),
      },
      true,
    );
  }

  @Permissions([Permission.SessionsApi])
  @Get(':userUuid')
  getSessionsByUserUUID(
    @Param('userUuid') userUUID: string,
    @Query() { agent }: GetSessionsQueryDto,
  ): Promise<SessionDto[]> {
    return this.sessionsService.findManyBy(
      {
        where: { userUUID: userUUID, agent: agent },
      },
      true,
    );
  }

  @AuthGuard()
  @Delete('@me/:id')
  deleteSessionMe(@Param('id') id: string): Promise<void> {
    return this.sessionsService.removeOneBy({ where: { id: id } });
  }

  @AuthGuard()
  @Delete('@me')
  deleteAllSessionsMe(@CurrentUser() user: ICurrentUser): Promise<void> {
    return this.sessionsService.removeManyBy({
      where: { userUUID: user.userUUID },
    });
  }

  @Permissions([Permission.SessionsApi])
  @Delete(':id')
  deleteSessionById(@Param('id') id: string): Promise<void> {
    return this.sessionsService.removeOneBy({ where: { id: id } });
  }

  @Permissions([Permission.SessionsApi])
  @Delete(':userUuid')
  deleteAllSessionsByUserUUID(
    @Param('userUuid') userUUID: string,
  ): Promise<void> {
    return this.sessionsService.removeManyBy({
      where: { userUUID: userUUID },
    });
  }
}
