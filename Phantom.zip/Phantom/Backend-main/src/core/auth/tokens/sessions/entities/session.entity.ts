import { Column, CreateDateColumn, Entity, PrimaryColumn } from 'typeorm';
import { SessionAgent } from '@/core/auth/tokens/sessions/enums/session-agent.enum';
import { Sortable } from '@common/sortable-properties/sortable.decorator';

@Entity('user_sessions')
export class SessionEntity {
  @PrimaryColumn()
  id: string;

  @Column()
  userUUID: string;

  @Column({ nullable: true })
  @Sortable()
  agent: SessionAgent;

  @CreateDateColumn()
  @Sortable()
  expiresAt: Date;
}
