import { IsEnum, IsNotEmpty, IsOptional } from 'class-validator';
import { SessionAgent } from '@/core/auth/tokens/sessions/enums/session-agent.enum';
import { PaginationDto, SortBy } from '@common/pagination/pagination.dto';
import { getSortableProperties } from '@common/sortable-properties/get-sortable-properties';
import { SessionEntity } from '@/core/auth/tokens/sessions/entities/session.entity';
import { SortLiteral } from '@common/pagination/get-pagination';

export class GetSessionsQueryDto extends PaginationDto implements SortBy {
  @IsNotEmpty()
  @IsEnum(getSortableProperties(SessionEntity))
  sortBy: SortLiteral;

  @IsOptional()
  @IsEnum(SessionAgent)
  agent?: SessionAgent;
}
