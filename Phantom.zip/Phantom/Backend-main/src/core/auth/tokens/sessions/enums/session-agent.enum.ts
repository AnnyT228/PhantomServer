export enum SessionAgent {
  Site = 'Site',
  Launcher = 'Launcher',
  DiscordOAuth = 'DiscordOAuth',
}
