export class CreateJwtPayload {
  id: string;

  user: string;
}

export class GetJwtPayload extends CreateJwtPayload {
  type: 'accessToken' | 'refreshToken';

  iat: number;

  exp: number;
}
