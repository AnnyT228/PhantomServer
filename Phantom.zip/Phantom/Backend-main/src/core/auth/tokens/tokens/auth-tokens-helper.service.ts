import { Request } from 'express';
import { Injectable } from '@nestjs/common';
import { instanceToPlain } from 'class-transformer';
import { TokensService } from '@/core/auth/tokens/tokens/tokens.service';
import { RoleMetadata } from '@/core/users/roles/roles/dto/role-metadata.dto';
import { UsersService } from '@/core/users/users/users.service';

@Injectable()
export class AuthTokensHelper {
  constructor(
    private readonly tokensService: TokensService,
    private readonly usersService: UsersService,
  ) {}

  extractTokenFromHeader(request: Request): {
    token: string;
    type: 'Access-Token' | 'Api-Key';
  } {
    const [type, token] = request.headers.authorization?.split(' ') ?? [];

    return {
      token,
      type,
    } as { token: string; type: 'Access-Token' | 'Api-Key' };
  }

  async getUserPermsFromToken(token: string): Promise<RoleMetadata> {
    const validateToken = await this.tokensService.validateToken(token);

    const user = await this.usersService.findOneBy({
      where: { id: validateToken.user },
    });

    return instanceToPlain(new RoleMetadata(user.roles)) as RoleMetadata;
  }
}
