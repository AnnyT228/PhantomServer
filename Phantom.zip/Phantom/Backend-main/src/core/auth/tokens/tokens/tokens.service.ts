import { BadRequestException, HttpStatus, Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { TokenExpiredError } from 'jsonwebtoken';
import { v4 as uuiv4 } from 'uuid';
import ms, { StringValue } from 'ms';
import {
  CreateJwtPayload,
  GetJwtPayload,
} from '@/core/auth/tokens/tokens/dto/jwt-payload.dto';
import { ApiException } from '@common/api-exceptions/api-exception.error';
import { SessionsService } from '@/core/auth/tokens/sessions/sessions.service';
import { SessionAgent } from '@/core/auth/tokens/sessions/enums/session-agent.enum';
import { envConfig } from '@common/configs/env.config';
import { Exceptions } from '@common/api-exceptions/exceptions.namespace';

@Injectable()
export class TokensService {
  constructor(
    private readonly jwtService: JwtService,
    private readonly sessionsService: SessionsService,
  ) {}

  async generateAccessToken(
    createJwtPayload: CreateJwtPayload,
  ): Promise<string> {
    return await this.jwtService.signAsync(
      { ...createJwtPayload, type: 'accessToken' },
      {
        expiresIn: envConfig.secure.jwt.accessExpiresAt,
      },
    );
  }

  async generateRefreshToken(
    createJwtPayload: CreateJwtPayload,
    agent: SessionAgent,
  ): Promise<string> {
    const thisDate = Date.now();
    const expiresAfter =
      thisDate + ms(envConfig.secure.jwt.refreshExpiresAt as StringValue);

    await this.sessionsService.saveSessionEntity({
      id: createJwtPayload.id,
      userUUID: createJwtPayload.user,
      agent: agent,
      expiresAt: new Date(expiresAfter),
    });

    return await this.jwtService.signAsync({
      ...createJwtPayload,
      iat: thisDate / 1000,
      exp: expiresAfter / 1000,
      type: 'refreshToken',
    });
  }

  async generateAccessViaRefresh(
    refreshToken: string,
    agent: SessionAgent,
  ): Promise<{ accessToken: string; refreshToken: string }> {
    const validateToken = await this.validateToken(refreshToken);

    await this.sessionsService.removeOneBy({ where: { id: validateToken.id } });

    const tokenId = uuiv4();

    return {
      accessToken: await this.generateAccessToken({
        user: validateToken.user,
        id: tokenId,
      }),
      refreshToken: await this.generateRefreshToken(
        { user: validateToken.user, id: tokenId },
        agent,
      ),
    };
  }

  async revokeRefreshToken(refreshToken: string): Promise<void> {
    const tokenDecode = await this.decodeToken<GetJwtPayload>(refreshToken);

    await this.sessionsService.removeOneBy({ where: { id: tokenDecode.id } });
  }

  async validateToken(token: string): Promise<GetJwtPayload> {
    const validatedToken = await this.jwtService
      .verifyAsync<GetJwtPayload>(token)
      .catch((error) => {
        if (error instanceof TokenExpiredError) {
          throw new ApiException(
            HttpStatus.BAD_REQUEST,
            'TokensExceptions',
            Exceptions.TokensExceptions.JwtTokenExpired,
          );
        } else {
          throw new ApiException(
            HttpStatus.BAD_REQUEST,
            'TokensExceptions',
            Exceptions.TokensExceptions.JwtTokenMalformed,
          );
        }
      });

    await this.sessionsService.findOneBy({ where: { id: validatedToken.id } });

    return validatedToken;
  }

  async decodeToken<T>(token: string): Promise<T> {
    try {
      return this.jwtService.decode(token) as T;
    } catch (e) {
      throw new BadRequestException();
    }
  }

  async getTokensPair(
    userUUID: string,
    agent: SessionAgent,
  ): Promise<{ accessToken: string; refreshToken: string }> {
    const tokenId = uuiv4();

    return {
      accessToken: await this.generateAccessToken({
        user: userUUID,
        id: tokenId,
      }),
      refreshToken: await this.generateRefreshToken(
        { user: userUUID, id: tokenId },
        agent,
      ),
    };
  }
}
