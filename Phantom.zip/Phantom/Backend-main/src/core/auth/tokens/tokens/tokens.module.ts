import { Module } from '@nestjs/common';
import { SessionsModule } from '@/core/auth/tokens/sessions/sessions.module';
import { UsersModule } from '@/core/users/users/users.module';
import { TokensService } from '@/core/auth/tokens/tokens/tokens.service';
import { AuthTokensHelper } from '@/core/auth/tokens/tokens/auth-tokens-helper.service';

@Module({
  imports: [SessionsModule, UsersModule],
  providers: [TokensService, AuthTokensHelper],
  exports: [TokensService, AuthTokensHelper],
})
export class TokensModule {}
