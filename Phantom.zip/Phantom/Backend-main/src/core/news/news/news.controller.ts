import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { FilesInterceptor } from '@nestjs/platform-express';
import { FileValidationPipe } from '@common/pipes/file-validation.pipe';
import { NewsService } from '@/core/news/news/news.service';
import { MemoryStorageFile } from '@/core/storage/types/memory-storage-file.type';
import { ValidatedBody } from '@common/validators/validated-body.decorator';
import { ChangeNewsDto } from '@/core/news/news/dto/change-news.dto';
import { NewsDto } from '@/core/news/news/dto/news.dto';
import { CreateNewsDto } from '@/core/news/news/dto/create-news.dto';
import { getPagination } from '@common/pagination/get-pagination';
import { GetManyNewsDto } from '@/core/news/news/dto/get-many-news.dto';

@ApiTags('news')
@Controller('news')
export class NewsController {
  constructor(private readonly newsService: NewsService) {}

  @Post()
  @UseInterceptors(FilesInterceptor('files'))
  createNews(
    @Body() createNewsDto: CreateNewsDto,
    @UploadedFiles(
      new FileValidationPipe({
        filesIsRequired: false,
        maxSizeInMiB: 100,
      }),
    )
    newsImages?: MemoryStorageFile[],
  ): Promise<void> {
    return this.newsService.createNews(createNewsDto, newsImages);
  }

  @Get(':id')
  getNewsById(@Param('id') id: number): Promise<NewsDto> {
    return this.newsService.findOneBy({ where: { id: id } }, true);
  }

  @Get()
  getManyNews(@Query() getManyNewsDto: GetManyNewsDto): Promise<NewsDto[]> {
    return this.newsService.findManyBy(
      {
        ...getPagination(getManyNewsDto),
      },
      true,
    );
  }

  @UseInterceptors(FilesInterceptor('files'))
  @Patch(':id')
  changeNews(
    @Param('id') id: number,
    @Body() changeNewsDto: ChangeNewsDto,
    @UploadedFiles(
      new FileValidationPipe({
        filesIsRequired: false,
        maxSizeInMiB: 100,
      }),
    )
    newsImages?: MemoryStorageFile[],
  ): Promise<void> {
    return this.newsService.changeNews(id, changeNewsDto, newsImages);
  }

  @Delete(':id')
  removeNews(@Param('id') id: number): Promise<void> {
    return this.newsService.removeNews(id);
  }

  @Delete()
  removeManyNews(@ValidatedBody('ids') ids: number[]): Promise<void> {
    return this.newsService.removeManyNews(ids);
  }
}
