import {
  Column,
  Entity,
  Generated,
  JoinColumn,
  OneToMany,
  PrimaryColumn,
} from 'typeorm';
import { CommentEntity } from '@/core/news/comments/entities/comment.entity';
import { Sortable } from '@common/sortable-properties/sortable.decorator';

export type NewsImageType = { filename: string; description: string };

@Entity('news')
export class NewsEntity {
  @Sortable()
  @PrimaryColumn()
  @Generated('increment')
  id: number;

  @Sortable()
  @Column()
  title: string;

  @Column()
  shortDescription: string;

  @Column()
  content: string;

  @Column({ type: 'simple-array' })
  tags: string[];

  @Column({ type: 'jsonb', nullable: true })
  attachments: NewsImageType[];

  @OneToMany(() => CommentEntity, (comment) => comment.news, {
    eager: true,
  })
  @JoinColumn()
  comments: CommentEntity[];

  @Sortable()
  @Column({ type: 'bigint' })
  createdAt: number;
}
