export enum NewsImagePatch {
  Add = 'Add',
  Change = 'Change',
  Delete = 'Delete',
}
