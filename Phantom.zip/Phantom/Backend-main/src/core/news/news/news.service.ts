import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Buffer } from 'buffer';
import { BaseEntityService } from '@common/other/abstract-base-entity.service';
import {
  NewsEntity,
  NewsImageType,
} from '@/core/news/news/entities/news.entity';
import { NewsDto } from '@/core/news/news/dto/news.dto';
import { CreateNewsDto } from '@/core/news/news/dto/create-news.dto';
import { MemoryStorageFile } from '@/core/storage/types/memory-storage-file.type';
import { StorageService } from '@/core/storage/storage.service';
import { ChangeNewsDto } from '@/core/news/news/dto/change-news.dto';
import { NewsImagePatch } from '@/core/news/news/enums/image-patch.enum';
import { NewsImageDto } from './dto/news-image.dto';

@Injectable()
export class NewsService extends BaseEntityService<NewsEntity, NewsDto> {
  constructor(
    @InjectRepository(NewsEntity)
    private readonly newsRepository: Repository<NewsEntity>,
    private readonly storageService: StorageService,
  ) {
    super(newsRepository, NewsDto);
  }

  async createNews(
    createNewsDto: CreateNewsDto,
    newsImages?: MemoryStorageFile[],
  ): Promise<void> {
    const images: NewsImageType[] = newsImages
      ? await Promise.all(
          newsImages?.map(async (image) => ({
            filename: await this.storageService.saveFile(image.buffer),
            description: Buffer.from(image.originalname, 'hex').toString(),
          })),
        )
      : [];

    await this.newsRepository.save({
      ...createNewsDto,
      createdAt: Date.now(),
      attachments: images,
    });
  }

  async changeNews(
    id: number,
    changeNewsDto: ChangeNewsDto,
    newsImages?: MemoryStorageFile[],
  ): Promise<void> {
    const news = await this.findOneBy({ where: { id: id } });

    if (
      newsImages.length &&
      newsImages.length !== changeNewsDto?.attachmentsDescriptions?.length
    ) {
      throw new BadRequestException();
    }

    if (
      newsImages.length &&
      newsImages.length === changeNewsDto?.attachmentsDescriptions?.length
    ) {
      await this.patchNewsAttachments(
        news.attachments,
        newsImages,
        changeNewsDto.attachmentsDescriptions,
      );
    }

    await this.updateOneBy(news, changeNewsDto);
  }

  async removeNews(id: number): Promise<void> {
    const news = await this.findOneBy({ where: { id: id } });

    if (news.attachments?.length) {
      const deleteResults = news.attachments.map((el) =>
        this.storageService.removeFile(el.filename),
      );

      await Promise.all(deleteResults);
    }

    await this.removeOneBy(news);
  }

  async removeManyNews(ids: number[]): Promise<void> {
    const manyNews = await this.findManyBy({ where: { id: In(ids) } });

    for await (const news of manyNews) {
      if (news.attachments?.length) {
        const deleteResults = news.attachments.map((el) =>
          this.storageService.removeFile(el.filename),
        );

        await Promise.all(deleteResults);
      }
    }

    await this.removeManyBy(manyNews);
  }

  private async patchNewsAttachments(
    newsAttachments: NewsImageType[] = [],
    newsImages: MemoryStorageFile[],
    attachmentsToChange: NewsImageDto[],
  ): Promise<NewsImageType[]> {
    for (const imageDto of attachmentsToChange) {
      /*
       * 1-ый сценарий - добавление нового изображения.
       * */
      switch (imageDto.type) {
        case NewsImagePatch.Add: {
          const imageToAdd = newsImages.find(
            (image) => image.originalname === imageDto.associatedFieldname,
          );

          if (!imageToAdd) throw new BadRequestException();

          const filename = await this.storageService.saveFile(
            imageToAdd.buffer,
          );

          newsAttachments.push({
            filename: filename,
            description: Buffer.from(imageToAdd.originalname, 'hex').toString(),
          });

          break;
        }
        /*
         * 2-ой сценарий - изменение фотографии на новую.
         * */
        case NewsImagePatch.Change: {
          const oldImageBuffer = await this.storageService.readFile(
            imageDto.associatedFilename,
          );
          const newImage = newsImages.find(
            (image) => image.fieldname === imageDto.associatedFieldname,
          );

          if (imageDto.associatedFieldname && !newImage) {
            throw new BadRequestException();
          }

          /*
           * 2.1 сценарий - изменение фотографии на новую (в т.ч. и её описания).
           *
           * Если изображения различаются, то отдаём выбор новому, удаляя старое.
           * После этого в this.updateOneBy сохраняем.
           * */
          if (
            newImage &&
            Buffer.compare(oldImageBuffer, newImage.buffer) !== 0
          ) {
            newsAttachments.filter(async (image) => {
              if (image.filename === imageDto.associatedFilename) {
                await this.storageService.removeFile(
                  imageDto.associatedFilename,
                );
              }

              return image.filename !== imageDto.associatedFilename;
            });

            const imageFilename = await this.storageService.saveFile(
              newImage.buffer,
            );

            newsAttachments.push({
              filename: imageFilename,
              /*
               * Отдельная реализация под сценарий, когда меняется и изображение
               * и его описание - не нужна, так как описание обновляется здесь.
               * */
              description: Buffer.from(newImage.originalname, 'hex').toString(),
            });

            /*
             * 2.2 сценарий - изменение описания, изображение остаётся старое.
             * */
          } else {
            const foundIndex = newsAttachments.findIndex(
              (image) => image.filename === imageDto.associatedFilename,
            );

            if (
              foundIndex !== -1 &&
              newsAttachments[foundIndex].description !== imageDto.description
            ) {
              newsAttachments[foundIndex] = {
                filename: imageDto.associatedFilename,
                description: imageDto.description,
              };
            }
          }

          break;
        }
        /*
         * 3-ий сценарий - удаление изображения.
         * */
        case NewsImagePatch.Delete: {
          /*
           * Удаляем изображение из найденной новости, если оно там есть.
           * После этого в this.updateOneBy сохраняем.
           * */
          newsAttachments.filter(async (image) => {
            if (image.filename === imageDto.associatedFilename) {
              await this.storageService.removeFile(imageDto.associatedFilename);
            }

            return image.filename !== imageDto.associatedFilename;
          });
        }
      }
    }

    return newsAttachments;
  }
}
