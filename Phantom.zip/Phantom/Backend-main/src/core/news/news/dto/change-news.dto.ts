import {
  ArrayMaxSize,
  ArrayMinSize,
  IsArray,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { NewsImageDto } from '@/core/news/news/dto/news-image.dto';

export class ChangeNewsDto {
  @IsOptional()
  @IsString()
  title?: string;

  @IsOptional()
  @IsString()
  shortDescription?: string;

  @IsOptional()
  @IsString()
  content?: string;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => NewsImageDto)
  attachmentsDescriptions?: NewsImageDto[];

  @IsOptional()
  @IsString({ each: true })
  @ArrayMinSize(1)
  @ArrayMaxSize(5)
  tags?: string[];
}
