import {
  ArrayMaxSize,
  ArrayMinSize,
  IsNotEmpty,
  IsString,
  MaxLength,
} from 'class-validator';

export class CreateNewsDto {
  @IsNotEmpty()
  @IsString()
  title: string;

  @IsNotEmpty()
  @IsString()
  shortDescription: string;

  @IsNotEmpty()
  @IsString()
  content: string;

  @IsNotEmpty()
  @IsString({ each: true })
  @MaxLength(14, {
    each: true,
  })
  @ArrayMinSize(1)
  @ArrayMaxSize(5)
  tags: string[];
}
