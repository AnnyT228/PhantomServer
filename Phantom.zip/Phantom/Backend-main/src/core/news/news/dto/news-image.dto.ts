import { IsEnum, IsNotEmpty, IsString, ValidateIf } from 'class-validator';
import { NewsImagePatch } from '@/core/news/news/enums/image-patch.enum';

export class NewsImageDto {
  @IsNotEmpty()
  @IsEnum(NewsImagePatch)
  type: NewsImagePatch;

  /*
   * Это поле нужно для определения, к какому изображению
   *  из сущности новости относится это DTO
   * */
  @ValidateIf(
    (dto: NewsImageDto) =>
      dto.type === NewsImagePatch.Change || dto.type === NewsImagePatch.Delete,
  )
  @IsNotEmpty()
  @IsString()
  associatedFilename: string;

  /*
   * Это поле нужно для определения, к какому изображению
   *  из body относится это DTO
   * */
  @ValidateIf(
    (dto: NewsImageDto) =>
      (dto.type === NewsImagePatch.Add || dto.type === NewsImagePatch.Change) &&
      !!dto.description,
  )
  @IsNotEmpty()
  @IsString()
  associatedFieldname: string;

  /*
   * Это поле нужно для смены описания уже сохранённого изображения
   * */
  @ValidateIf(
    (dto: NewsImageDto) =>
      dto.type === NewsImagePatch.Change && !!dto.associatedFieldname,
  )
  @IsNotEmpty()
  @IsString()
  description: string;
}
