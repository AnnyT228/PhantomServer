import { IsEnum, IsNotEmpty } from 'class-validator';
import { PaginationDto } from '@common/pagination/pagination.dto';
import { getSortableProperties } from '@common/sortable-properties/get-sortable-properties';
import { NewsEntity } from '@/core/news/news/entities/news.entity';
import { SortLiteral } from '@common/pagination/get-pagination';

export class GetManyNewsDto extends PaginationDto {
  @IsNotEmpty()
  @IsEnum(getSortableProperties(NewsEntity))
  sortBy: SortLiteral;
}
