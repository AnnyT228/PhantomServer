import { Exclude, Expose, Transform } from 'class-transformer';
import { CommentDto } from '@/core/news/comments/dto/comment.dto';
import {
  NewsEntity,
  NewsImageType,
} from '@/core/news/news/entities/news.entity';
import { StorageService } from '@/core/storage/storage.service';

@Exclude()
export class NewsDto {
  @Expose()
  id: number;

  @Expose()
  title: string;

  @Expose()
  content: string;

  @Expose()
  comments: CommentDto[];

  @Expose()
  attachments: NewsImageType[];

  @Expose()
  tags: string[];

  @Expose()
  @Transform(({ value }) => new Date(Number(value)))
  createdAt: Date;

  constructor(newsEntity: NewsEntity) {
    Object.assign(this, newsEntity);

    this.comments = newsEntity.comments.map(
      (comment) => new CommentDto(comment),
    );

    if (this.attachments.length) {
      this.attachments.forEach(
        (el, index, arr) =>
          (arr[index].filename = StorageService.getInstance.getFileUrl(
            el.filename,
          ).href),
      );
    }
  }
}
