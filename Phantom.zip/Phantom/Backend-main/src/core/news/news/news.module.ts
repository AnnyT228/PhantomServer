import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NewsController } from '@/core/news/news/news.controller';
import { NewsService } from '@/core/news/news/news.service';
import { NewsEntity } from '@/core/news/news/entities/news.entity';
import { StorageModule } from '@/core/storage/storage.module';

@Module({
  imports: [TypeOrmModule.forFeature([NewsEntity]), StorageModule],
  controllers: [NewsController],
  providers: [NewsService],
  exports: [NewsService, TypeOrmModule],
})
export class NewsModule {}
