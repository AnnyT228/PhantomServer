import { Module } from '@nestjs/common';
import { NewsModule } from '@/core/news/news/news.module';
import { CommentsModule } from '@/core/news/comments/comments.module';

@Module({
  imports: [NewsModule, CommentsModule],
  exports: [NewsModule, CommentsModule],
})
export class NewsMainModule {}
