import {
  Column,
  CreateDateColumn,
  Entity,
  Generated,
  ManyToOne,
  PrimaryColumn,
} from 'typeorm';
import { NewsEntity } from '@/core/news/news/entities/news.entity';

@Entity('news_comments')
export class CommentEntity {
  @PrimaryColumn()
  @Generated('increment')
  id: number;

  @ManyToOne(() => NewsEntity, (news) => news.comments)
  news: NewsEntity;

  @Column()
  username: string;

  @Column({ default: false })
  modified: boolean;

  @Column()
  content: string;

  @Column()
  @CreateDateColumn({
    type: 'timestamp',
  })
  createdAt: string;
}
