import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { BaseEntityService } from '@common/other/abstract-base-entity.service';
import { CommentEntity } from '@/core/news/comments/entities/comment.entity';
import { CommentDto } from '@/core/news/comments/dto/comment.dto';

@Injectable()
export class CommentsService extends BaseEntityService<
  CommentEntity,
  CommentDto
> {
  constructor(
    @InjectRepository(CommentEntity)
    private readonly commentsRepository: Repository<CommentEntity>,
  ) {
    super(commentsRepository, CommentDto);
  }
}
