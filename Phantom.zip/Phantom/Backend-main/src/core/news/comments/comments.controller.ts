import { Controller } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { CommentsService } from '@/core/news/comments/comments.service';

@ApiTags('news/comments')
@Controller('news/comments')
export class CommentsController {
  constructor(private readonly commentsService: CommentsService) {}

  // @Post()
  // createComment(@Param('id') newsId: number) {}
  //
  // @Patch(':id')
  // changeComment(@Param('id') id: number) {}
  //
  // @Get(':newsId')
  // getCommentByNewsId(@Param('newsId') newsId: number): Promise<CommentDto> {
  //   return this.commentsService.findOneBy(
  //     { where: { news: { id: newsId } } },
  //     true,
  //   );
  // }
  //
  // @Get(':id')
  // getCommentById(@Param('id') id: number): Promise<CommentDto> {
  //   return this.commentsService.findOneBy({ where: { id: id } }, true);
  // }
  //
  // @Delete()
  // removeComment() {}
  //
  // @Delete()
  // removeCommentMe() {}
  //
  // @Delete()
  // removeManyComments() {}
}
