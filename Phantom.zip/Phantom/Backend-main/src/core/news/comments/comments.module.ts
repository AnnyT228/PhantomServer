import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CommentsService } from '@/core/news/comments/comments.service';
import { CommentEntity } from '@/core/news/comments/entities/comment.entity';
import { CommentsController } from '@/core/news/comments/comments.controller';

@Module({
  imports: [TypeOrmModule.forFeature([CommentEntity])],
  controllers: [CommentsController],
  providers: [CommentsService],
  exports: [CommentsService, TypeOrmModule],
})
export class CommentsModule {}
