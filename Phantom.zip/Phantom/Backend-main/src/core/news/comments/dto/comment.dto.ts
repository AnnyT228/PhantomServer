import { Exclude, Expose, Transform } from 'class-transformer';
import { CommentEntity } from '@/core/news/comments/entities/comment.entity';

@Exclude()
export class CommentDto {
  @Expose()
  username: string;

  @Expose()
  content: string;

  @Expose()
  @Transform(({ value }) => new Date(value))
  createdAt: Date;

  constructor(commentEntity: CommentEntity) {
    Object.assign(this, commentEntity);
  }
}
