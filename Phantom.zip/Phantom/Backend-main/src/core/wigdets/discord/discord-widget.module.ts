import { Module } from '@nestjs/common';
import { DiscordWidgetService } from '@/core/wigdets/discord/discord-widget.service';
import { DiscordWidgetController } from '@/core/wigdets/discord/discord-widget.controller';
import { WidgetType } from '@/core/wigdets/widgets-core/enums/widget.type';
import { envConfig } from '@common/configs/env.config';
import { WidgetCore } from '@/core/wigdets/widgets-core/abstracts/widget-core.abstract';

@Module({
  controllers: [DiscordWidgetController],
  providers: [DiscordWidgetService],
  exports: [DiscordWidgetService],
})
export class DiscordWidgetModule extends WidgetCore {
  id: WidgetType = WidgetType.Discord;
  enabled: boolean = envConfig.widgets.discord.enabled;
}
