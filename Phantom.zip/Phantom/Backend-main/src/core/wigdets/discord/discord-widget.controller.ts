import { Controller, Get } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { DiscordWidgetService } from '@/core/wigdets/discord/discord-widget.service';
import { DiscordWidgetDto } from '@/core/wigdets/discord/dto/discord-widget.dto';

@ApiTags('widgets')
@Controller('widgets/discord')
export class DiscordWidgetController {
  constructor(private readonly discordWidgetService: DiscordWidgetService) {}

  @Get()
  getInfo(): Promise<DiscordWidgetDto> {
    return this.discordWidgetService.getWidget();
  }
}
