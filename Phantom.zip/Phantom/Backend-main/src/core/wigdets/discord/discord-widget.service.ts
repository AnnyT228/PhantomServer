import { REST } from '@discordjs/rest';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import {
  Inject,
  Injectable,
  ServiceUnavailableException,
} from '@nestjs/common';
import { Cache } from 'cache-manager';
import { APIGuild, APIGuildWidget, Routes } from 'discord-api-types/v10';
import ms from 'ms';
import { DiscordWidgetUserDto } from '@/core/wigdets/discord/dto/discord-widget-user.dto';
import { DiscordWidgetDto } from '@/core/wigdets/discord/dto/discord-widget.dto';
import { envConfig } from '@common/configs/env.config';

@Injectable()
export class DiscordWidgetService {
  private readonly rest = new REST({
    authPrefix: 'Bot',
    version: '10',
  });

  constructor(
    @Inject(CACHE_MANAGER)
    private readonly cacheManager: Cache,
  ) {
    this.rest.setToken(envConfig.widgets.discord.botToken);
  }

  async getWidget(): Promise<DiscordWidgetDto> {
    const cachedWidget =
      await this.cacheManager.get<DiscordWidgetDto>('DiscordWidget');

    if (cachedWidget) return cachedWidget;

    const [apiGuild, apiGuildWidget] = await Promise.all([
      this.rest.get(
        Routes.guild(envConfig.widgets.discord.guildId),
      ) as Promise<APIGuild>,
      this.rest.get(
        Routes.guildWidgetJSON(envConfig.widgets.discord.guildId),
      ) as Promise<APIGuildWidget>,
    ]).catch(() => {
      throw new ServiceUnavailableException();
    });

    const users = apiGuildWidget.members.map((user) => {
      return new DiscordWidgetUserDto({
        username: user.username,
        avatar: user.avatar_url,
        activity: {
          name: user.activity?.name ?? null,
          status: user.status,
        },
      });
    });

    const discordWidgetDto = new DiscordWidgetDto({
      name: apiGuild.name,
      description: apiGuild.description,
      invite: apiGuildWidget.instant_invite,
      icon: apiGuild.icon
        ? `https://cdn.discordapp.com/icons/${apiGuild.id}/${apiGuild.icon}`
        : null,
      banner: apiGuild.banner
        ? `https://cdn.discordapp.com/banners/${apiGuild.id}/${apiGuild.banner}`
        : null,
      users: users,
    });

    await this.cacheManager.set('DiscordWidget', discordWidgetDto, ms('5m'));

    return discordWidgetDto;
  }
}
