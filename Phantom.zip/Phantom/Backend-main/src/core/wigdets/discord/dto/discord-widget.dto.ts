import { Expose } from 'class-transformer';
import { DiscordWidgetUserDto } from '@/core/wigdets/discord/dto/discord-widget-user.dto';

export class DiscordWidgetDto {
  @Expose()
  name: string;

  @Expose()
  description: string;

  @Expose()
  invite: string;

  @Expose()
  icon: string;

  @Expose()
  banner: string;

  @Expose()
  users: DiscordWidgetUserDto[];

  constructor(widgetData: {
    name: string;
    description: string;
    invite: string;
    icon: string;
    banner: string;
    users: DiscordWidgetUserDto[];
  }) {
    Object.assign(this, widgetData);
  }
}
