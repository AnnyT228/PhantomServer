import { Expose } from 'class-transformer';

export class DiscordWidgetUserDto {
  @Expose()
  username: string;

  @Expose()
  avatar: string;

  @Expose()
  activity: {
    status: string;
    name: string;
  };

  constructor(userData: {
    username: string;
    avatar: string;
    activity: {
      status: string;
      name: string;
    };
  }) {
    Object.assign(this, userData);
  }
}
