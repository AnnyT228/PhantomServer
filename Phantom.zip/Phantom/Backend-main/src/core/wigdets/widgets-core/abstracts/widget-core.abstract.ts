import { WidgetType } from '@/core/wigdets/widgets-core/enums/widget.type';

export abstract class WidgetCore {
  static id: WidgetType;
  static enabled: boolean;
}
