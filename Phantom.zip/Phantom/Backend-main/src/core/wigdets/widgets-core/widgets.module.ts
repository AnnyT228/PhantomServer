import { Module, OnModuleInit } from '@nestjs/common';
import { DiscordWidgetModule } from '@/core/wigdets/discord/discord-widget.module';
import { WidgetsController } from '@/core/wigdets/widgets-core/widgets.controller';
import { WidgetsService } from '@/core/wigdets/widgets-core/widgets.service';
import 'reflect-metadata';

const processedWidgets = [DiscordWidgetModule].map((el) => {
  let moduleInstance = new el();
  const { id, enabled } = moduleInstance;

  moduleInstance = undefined;

  if (id && enabled) {
    return {
      module: el,
      id: id,
    };
  }
});

@Module({
  imports: [...processedWidgets],
  controllers: [WidgetsController],
  providers: [WidgetsService],
  exports: [WidgetsService, ...processedWidgets],
})
export class WidgetsModule implements OnModuleInit {
  constructor(private readonly widgetsService: WidgetsService) {}

  onModuleInit(): any {
    this.widgetsService.enabledWidgets = processedWidgets.map(
      (widget) => widget.id,
    );
  }
}
