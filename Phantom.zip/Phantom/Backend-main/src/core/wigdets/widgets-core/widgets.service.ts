import { Injectable } from '@nestjs/common';
import { WidgetType } from '@/core/wigdets/widgets-core/enums/widget.type';

@Injectable()
export class WidgetsService {
  enabledWidgets: WidgetType[] = [];

  get enabled(): WidgetType[] {
    return this.enabledWidgets;
  }
}
