export enum WidgetType {
  Discord = 'discord',
  Vk = 'vk',
}
