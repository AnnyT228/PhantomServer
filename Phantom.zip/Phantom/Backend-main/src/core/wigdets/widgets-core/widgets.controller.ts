import { Controller, Get } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { WidgetsService } from '@/core/wigdets/widgets-core/widgets.service';
import { WidgetType } from '@/core/wigdets/widgets-core/enums/widget.type';

@ApiTags('widgets')
@Controller('widgets')
export class WidgetsController {
  constructor(private readonly widgetsService: WidgetsService) {}

  @Get()
  getEnabledWidgets(): WidgetType[] {
    return this.widgetsService.enabled;
  }
}
