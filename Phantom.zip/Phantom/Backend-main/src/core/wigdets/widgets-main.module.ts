import { Module } from '@nestjs/common';
import { WidgetsModule } from '@/core/wigdets/widgets-core/widgets.module';

@Module({
  imports: [WidgetsModule],
  exports: [WidgetsModule],
})
export class WidgetsMainModule {}
