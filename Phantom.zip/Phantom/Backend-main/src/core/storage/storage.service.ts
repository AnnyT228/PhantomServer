import { Injectable, NotFoundException, StreamableFile } from '@nestjs/common';
import { v4 as uuidv4 } from 'uuid';
import { createHash } from 'crypto';
import { access, mkdir, readFile, unlink, writeFile } from 'fs/promises';
import { Buffer } from 'buffer';
import { resolve } from 'path';
import { envConfig } from '@common/configs/env.config';
import { MemoryStorageFile } from '@/core/storage/types/memory-storage-file.type';
import { ImageMime } from '@/core/storage/types/image-mime.type';

@Injectable()
export class StorageService {
  private readonly storageFolderPath = resolve(process.cwd(), 'storage');
  private static storageServiceInstance: StorageService;

  static set setInstance(instance: StorageService) {
    this.storageServiceInstance = instance;
  }

  static get getInstance(): StorageService {
    return this.storageServiceInstance;
  }

  async streamByFilename(filename: string): Promise<StreamableFile> {
    const fileStream = await this.readFile(filename);

    if (!fileStream) throw new NotFoundException();

    return new StreamableFile(fileStream);
  }

  async saveFile(fileBuffer: Buffer): Promise<string> {
    const filename = this.generateFilename(fileBuffer);

    await this.writeFile({
      buffer: fileBuffer,
      name: filename,
    });

    return filename;
  }

  checkStorageFolder(): Promise<void> {
    return access(this.storageFolderPath).catch((error) => {
      if ('code' in error && error?.code === 'ENOENT') {
        return mkdir(this.storageFolderPath);
      }

      throw error;
    });
  }

  private generateFilename(file: MemoryStorageFile | Buffer): string {
    if (file instanceof Buffer) {
      return `${uuidv4()}.${this.getFileMimeType(file)}`;
    }

    return `${uuidv4()}.${this.getFileMimeType(file.buffer)}`;
  }

  async readFile(filename: string): Promise<Buffer> {
    try {
      return await readFile(resolve(this.storageFolderPath, filename));
    } catch (e) {}
  }

  private async writeFile(file: {
    name: string;
    buffer: Buffer;
  }): Promise<void> {
    return await writeFile(
      resolve(this.storageFolderPath, file.name),
      file.buffer,
    );
  }

  async removeFile(filename: string): Promise<void> {
    try {
      await unlink(resolve(this.storageFolderPath, filename));
    } catch (error) {}
  }

  getFileDigest(file: Buffer): string {
    return createHash('sha256').update(file).digest('hex');
  }

  getFileMimeType(fileBuffer: Buffer): ImageMime {
    const fileBufferToHex = fileBuffer.toString('hex').toUpperCase();

    switch (true) {
      case fileBufferToHex.startsWith('89504E470D0A1A0A'): {
        return 'png';
      }
      case fileBufferToHex.startsWith('FFD8FF'): {
        return 'jpeg';
      }
      case fileBufferToHex.startsWith('474946'): {
        return 'gif';
      }
      case fileBufferToHex.startsWith('49492A00') ||
        fileBufferToHex.startsWith('4D4D002A'): {
        return 'tiff';
      }
    }
  }

  getFileUrl(filename: string): URL {
    return new URL(`storage/${filename}`, envConfig.api.url);
  }
}
