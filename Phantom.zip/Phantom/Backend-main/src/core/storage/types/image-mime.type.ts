export type ImageMime = 'png' | 'jpeg' | 'gif' | 'tiff';
