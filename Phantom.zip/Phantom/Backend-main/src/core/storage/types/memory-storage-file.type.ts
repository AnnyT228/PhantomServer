export type MemoryStorageFile = Omit<
  Express.Multer.File,
  'destination' | 'filename' | 'path' | 'stream'
>;
