import { Module, OnModuleInit } from '@nestjs/common';
import { StorageService } from '@/core/storage/storage.service';
import { StorageController } from '@/core/storage/storage.controller';

@Module({
  controllers: [StorageController],
  providers: [StorageService],
  exports: [StorageService],
})
export class StorageModule implements OnModuleInit {
  constructor(private readonly storageService: StorageService) {}

  async onModuleInit(): Promise<any> {
    StorageService.setInstance = this.storageService;

    await this.storageService.checkStorageFolder();
  }
}
