import { Controller, Get, Header, Param, StreamableFile } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { StorageService } from '@/core/storage/storage.service';

@ApiTags('storage')
@Controller('storage')
export class StorageController {
  constructor(private readonly storageService: StorageService) {}

  @Get(':filename')
  @Header('Content-Type', 'image/png')
  streamByFilename(
    @Param('filename') filename: string,
  ): Promise<StreamableFile> {
    return this.storageService.streamByFilename(filename);
  }
}
