import { All, Controller, Redirect } from '@nestjs/common';
import { envConfig } from '@common/configs/env.config';

@Controller()
export class AppController {
  @All()
  @Redirect()
  redirectToMain(): { url: string } {
    return { url: envConfig.api.frontendUrl.href };
  }
}
