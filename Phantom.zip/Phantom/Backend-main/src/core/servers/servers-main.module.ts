import { Module } from '@nestjs/common';
import { ServersModule } from '@/core/servers/servers/servers.module';
import { MonitoringsModule } from '@/core/servers/monitorings/monitorings.module';

@Module({
  imports: [ServersModule, MonitoringsModule],
  exports: [ServersModule, MonitoringsModule],
})
export class ServersMainModule {}
