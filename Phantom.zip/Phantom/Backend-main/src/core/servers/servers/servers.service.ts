import { ConflictException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Like, Repository } from 'typeorm';
import { ServerEntity } from '@/core/servers/servers/entities/server.entity';
import { CreateServerDto } from '@/core/servers/servers/dto/create-server.dto';
import { ServerDto } from '@/core/servers/servers/dto/server.dto';
import { GetServersQueryDto } from '@/core/servers/servers/dto/get-servers-query.dto';
import { ChangeServerDto } from '@/core/servers/servers/dto/change-server.dto';
import { StorageService } from '@/core/storage/storage.service';
import { BaseEntityService } from '@common/other/abstract-base-entity.service';
import { getPagination } from '@common/pagination/get-pagination';
import { MemoryStorageFile } from '@/core/storage/types/memory-storage-file.type';

@Injectable()
export class ServersService extends BaseEntityService<ServerEntity, ServerDto> {
  constructor(
    @InjectRepository(ServerEntity)
    private readonly serversRepository: Repository<ServerEntity>,
    private readonly storageService: StorageService,
  ) {
    super(serversRepository, ServerDto);
  }

  async createServer(
    createServerDto: CreateServerDto,
    file: MemoryStorageFile,
  ): Promise<void> {
    const uniqueId = createServerDto.name.replaceAll(' ', '').toLowerCase();

    const existServer = await this.findOneBy({
      where: [{ uniqueId: uniqueId }, { name: createServerDto.name }],
    }).catch((err) => {});

    if (existServer) throw new ConflictException();

    const filename = await this.storageService.saveFile(file.buffer);

    await this.serversRepository.save({
      ...createServerDto,
      uniqueId: uniqueId,
      icon: filename,
    });
  }

  async findAll(getServersDto: GetServersQueryDto): Promise<ServerDto[]> {
    return await this.findManyBy(
      {
        where: getServersDto.includes
          ? { name: Like(`%${getServersDto.includes}%`) }
          : undefined,
        ...getPagination(getServersDto),
      },
      true,
    );
  }

  async changeServer(
    uniqueId: string,
    changeServerDto: ChangeServerDto,
    file?: MemoryStorageFile,
  ): Promise<void> {
    const server = await this.findOneBy({ where: { uniqueId: uniqueId } });

    if (changeServerDto.name !== server.name) {
      server.uniqueId = changeServerDto.name?.replaceAll(' ', '').toLowerCase();
    }

    if (file) {
      if (server.icon) await this.storageService.removeFile(server.icon);
      server.icon = await this.storageService.saveFile(file.buffer);
    }

    await this.updateOneBy(server, {
      ...changeServerDto,
    });
  }
}
