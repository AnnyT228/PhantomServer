import { Column, Entity, Generated, PrimaryColumn } from 'typeorm';
import { Sortable } from '@common/sortable-properties/sortable.decorator';

@Entity('servers')
export class ServerEntity {
  @PrimaryColumn()
  @Generated('increment')
  id: number;

  @Column()
  uniqueId: string;

  @Column()
  @Sortable()
  name: string;

  @Column()
  @Sortable()
  version: string;

  @Column()
  @Sortable()
  priority: number;

  @Column()
  description: string;

  @Column({ nullable: true })
  icon: string;
}
