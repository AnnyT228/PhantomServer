import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { CreateServerDto } from '@/core/servers/servers/dto/create-server.dto';
import { ServersService } from '@/core/servers/servers/servers.service';
import { Permissions } from '@/core/users/roles/permissions/decorators/permissions.decorator';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';
import { GetServersQueryDto } from '@/core/servers/servers/dto/get-servers-query.dto';
import { ChangeServerDto } from '@/core/servers/servers/dto/change-server.dto';
import { FileHandler } from '@common/other/file-handler';
import { FileValidationPipe } from '@common/pipes/file-validation.pipe';
import { MemoryStorageFile } from '@/core/storage/types/memory-storage-file.type';
import { ServerDto } from '@/core/servers/servers/dto/server.dto';

@ApiTags('servers')
@Controller('servers')
export class ServersController {
  constructor(private readonly serversService: ServersService) {}

  @Permissions([Permission.ServersApi])
  @UseInterceptors(FileHandler)
  @Post()
  createServer(
    @Body() createServerDto: CreateServerDto,
    @UploadedFile(
      new FileValidationPipe({
        filesIsRequired: true,
        maxSizeInMiB: 10,
      }),
    )
    file: MemoryStorageFile,
  ): Promise<void> {
    return this.serversService.createServer(createServerDto, file);
  }

  @Get(':uniqueId')
  findServerByUniqueId(
    @Param('uniqueId') uniqueId: string,
  ): Promise<ServerDto> {
    return this.serversService.findOneBy(
      { where: { uniqueId: uniqueId } },
      true,
    );
  }

  @Get()
  findAllServers(
    @Query() getServersDto: GetServersQueryDto,
  ): Promise<ServerDto[]> {
    return this.serversService.findAll(getServersDto);
  }

  @Permissions([Permission.ServersApi])
  @UseInterceptors(FileHandler)
  @Patch(':uniqueId')
  changeServer(
    @Param('uniqueId') uniqueId: string,
    @Body() changeServerDto: ChangeServerDto,
    @UploadedFile(
      new FileValidationPipe({ filesIsRequired: false, maxSizeInMiB: 10 }),
    )
    file: MemoryStorageFile,
  ): Promise<void> {
    return this.serversService.changeServer(uniqueId, changeServerDto, file);
  }

  @Permissions([Permission.ServersApi])
  @Delete(':uniqueId')
  deleteServer(@Param('uniqueId') uniqueId: string): Promise<void> {
    return this.serversService.removeOneBy({
      where: { uniqueId: uniqueId },
    });
  }
}
