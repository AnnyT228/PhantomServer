import { IsEnum, IsNotEmpty } from 'class-validator';
import { getSortableProperties } from '@common/sortable-properties/get-sortable-properties';
import { ServerEntity } from '@/core/servers/servers/entities/server.entity';
import { PaginationDto, SortBy } from '@common/pagination/pagination.dto';
import { SortLiteral } from '@common/pagination/get-pagination';

export class GetServersQueryDto extends PaginationDto implements SortBy {
  @IsNotEmpty()
  @IsEnum(getSortableProperties(ServerEntity))
  sortBy: SortLiteral;
}
