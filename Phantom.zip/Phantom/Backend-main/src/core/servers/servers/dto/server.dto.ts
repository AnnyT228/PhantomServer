import { Exclude, Expose } from 'class-transformer';
import { ServerEntity } from '@/core/servers/servers/entities/server.entity';
import { StorageService } from '@/core/storage/storage.service';

@Exclude()
export class ServerDto {
  @Expose()
  uniqueId: string;

  @Expose()
  name: string;

  @Expose()
  version: string;

  @Expose()
  priority: number;

  @Expose()
  description: string;

  @Expose()
  icon: string;

  constructor(partial: Partial<ServerEntity>) {
    Object.assign(this, partial);

    this.icon = partial.icon
      ? StorageService.getInstance.getFileUrl(partial.icon).href
      : null;
  }
}
