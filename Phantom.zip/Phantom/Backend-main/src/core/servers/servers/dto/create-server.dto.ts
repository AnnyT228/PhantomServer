import { IsInt, IsNotEmpty, IsString, Length } from 'class-validator';
import { Type } from 'class-transformer';
import { StringWithoutSpaces } from '@common/validators/string-without-spaces.decorator';

export class CreateServerDto {
  @IsNotEmpty()
  @IsString()
  @Length(3, 16)
  name: string;

  @IsNotEmpty()
  @IsString()
  @StringWithoutSpaces()
  version: string;

  @IsNotEmpty()
  @IsInt()
  @Type(() => Number)
  priority: number;

  @IsNotEmpty()
  @IsString()
  description: string;
}
