import { PartialType } from '@nestjs/swagger';
import { CreateServerDto } from '@/core/servers/servers/dto/create-server.dto';

export class ChangeServerDto extends PartialType(CreateServerDto) {}
