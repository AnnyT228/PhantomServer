import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ServerEntity } from '@/core/servers/servers/entities/server.entity';
import { ServersController } from '@/core/servers/servers/servers.controller';
import { ServersService } from '@/core/servers/servers/servers.service';
import { StorageModule } from '@/core/storage/storage.module';

@Module({
  imports: [TypeOrmModule.forFeature([ServerEntity]), StorageModule],
  controllers: [ServersController],
  providers: [ServersService],
  exports: [ServersService, TypeOrmModule],
})
export class ServersModule {}
