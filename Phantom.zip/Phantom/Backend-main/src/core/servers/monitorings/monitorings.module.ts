import { Module } from '@nestjs/common';
import { MonitoringsGateway } from '@/core/servers/monitorings/monitorings.gateway';
import { TokensMainModule } from '@/core/auth/tokens/tokens-main.module';
import { ServersModule } from '@/core/servers/servers/servers.module';

@Module({
  imports: [TokensMainModule, ServersModule],
  providers: [MonitoringsGateway],
})
export class MonitoringsModule {}
