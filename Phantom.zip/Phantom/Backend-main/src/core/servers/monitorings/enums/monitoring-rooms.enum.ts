export enum MonitoringRooms {
  OutgoingMonitorings = 'OutgoingMonitorings',
  AcceptingMonitorings = 'AcceptingMonitorings',
}
