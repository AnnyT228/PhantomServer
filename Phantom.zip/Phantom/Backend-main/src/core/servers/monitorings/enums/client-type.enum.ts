export enum ClientTypeEnum {
  OutgoingMonitoring = 'OutgoingMonitoring',
  AcceptingMonitoring = 'AcceptingMonitoring',
}
