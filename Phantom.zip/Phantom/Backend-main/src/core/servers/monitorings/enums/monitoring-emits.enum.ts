export enum MonitoringEmits {
  GetMonitoringInfo = 'GetMonitoringInfo',
  ReceivingMonitoringInfo = 'ReceivingMonitoringInfo',

  OutgoingMonitoringDisabled = 'OutgoingMonitoringDisabled',
}
