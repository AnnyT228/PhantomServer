export enum MonitoringMessagesEnum {
  SendMonitoringInfo = 'SendMonitoringInfo',
}
