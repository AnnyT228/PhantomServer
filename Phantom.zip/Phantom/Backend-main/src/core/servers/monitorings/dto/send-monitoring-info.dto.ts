import { IsInt, IsNotEmpty, IsString, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { StringWithoutSpaces } from '@common/validators/string-without-spaces.decorator';

class PlayerProfile {
  @IsNotEmpty()
  @IsString()
  username: string;

  @IsNotEmpty()
  @IsString()
  skinTexture: string;
}

class ServerInfoDto {
  @IsNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => PlayerProfile)
  players: PlayerProfile[];

  @IsNotEmpty()
  @IsInt()
  count: number;

  @IsNotEmpty()
  @IsInt()
  maxOnline: number;
}

export class SendMonitoringInfoDto {
  @IsNotEmpty()
  @IsString()
  @StringWithoutSpaces()
  serverId: string;

  @IsNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => ServerInfoDto)
  info: ServerInfoDto;
}
