import {
  MessageBody,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import {
  BadRequestException,
  HttpStatus,
  Inject,
  OnModuleDestroy,
  UseFilters,
  UseGuards,
  UsePipes,
} from '@nestjs/common';
import { Server, Socket } from 'socket.io';
import { from } from 'rxjs';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import { CustomValidationPipe } from '@common/pipes/validation-pipe';
import { MonitoringRooms } from '@/core/servers/monitorings/enums/monitoring-rooms.enum';
import { MonitoringEmits } from '@/core/servers/monitorings/enums/monitoring-emits.enum';
import { MonitoringMessagesEnum } from '@/core/servers/monitorings/enums/monitoring-messages.enum';
import { ClientTypeEnum } from '@/core/servers/monitorings/enums/client-type.enum';
import { WsPermissionGuard } from '@/core/users/roles/permissions/guards/ws-permission.guard';
import { Permission } from '@/core/users/roles/permissions/enums/permissions.enum';
import { ApiException } from '@common/api-exceptions/api-exception.error';
import { ServersService } from '@/core/servers/servers/servers.service';
import { SendMonitoringInfoDto } from '@/core/servers/monitorings/dto/send-monitoring-info.dto';
import { ApiExceptionHandler } from '@common/api-exceptions/api-exception.handler';

@UsePipes(CustomValidationPipe)
@UseFilters(ApiExceptionHandler)
@WebSocketGateway({
  namespace: 'servers/monitorings',
  cors: {
    origin: true,
  },
})
export class MonitoringsGateway
  implements OnGatewayConnection, OnGatewayDisconnect, OnModuleDestroy
{
  @WebSocketServer()
  private readonly webSocketServer: Server;

  private readonly outgoingsMonitoringsSockets = new Set<string>();

  constructor(
    @Inject(CACHE_MANAGER)
    private readonly cacheManager: Cache,
    private readonly serversService: ServersService,
  ) {}

  private parseMetadata(client: Socket): {
    clientType: ClientTypeEnum;
    socketId: string;
  } {
    try {
      return JSON.parse(client.handshake.headers?.metadata as string);
    } catch (e) {
      client.emit(
        'exception',
        new ApiException(
          HttpStatus.BAD_REQUEST,
          'HttpExceptions',
          BadRequestException.name,
        ),
      );

      client.disconnect(true);
    }
  }

  async handleConnection(client: Socket, ...args: any[]): Promise<any> {
    const metadata = this.parseMetadata(client);

    if (!metadata) return client.disconnect();

    if (metadata.clientType === ClientTypeEnum.OutgoingMonitoring) {
      const serverId = metadata.socketId.split(':')[1];

      if (this.outgoingsMonitoringsSockets.has(serverId)) {
        client.emit(
          'exception',
          new ApiException(
            HttpStatus.BAD_REQUEST,
            'HttpExceptions',
            'ConflictException',
          ),
        );

        return client.disconnect(true);
      }

      await this.serversService
        .findOneBy({
          where: { uniqueId: serverId },
        })
        .catch((e) => {
          client.emit('exception', e);

          return client.disconnect(true);
        });

      this.outgoingsMonitoringsSockets.add(serverId);

      client.join(MonitoringRooms.OutgoingMonitorings);

      client.emit(MonitoringEmits.GetMonitoringInfo);
    } else if (metadata.clientType === ClientTypeEnum.AcceptingMonitoring) {
      client.join(MonitoringRooms.AcceptingMonitorings);

      const allServersInfo: SendMonitoringInfoDto[] = [];

      from(this.outgoingsMonitoringsSockets).subscribe(async (el) => {
        const monitoringInfo =
          await this.cacheManager.get<SendMonitoringInfoDto>(el);

        allServersInfo.push(monitoringInfo);

        this.webSocketServer
          .to(MonitoringRooms.AcceptingMonitorings)
          .emit(MonitoringEmits.ReceivingMonitoringInfo, allServersInfo);
      });
    }
  }

  async handleDisconnect(client: Socket): Promise<any> {
    const metadata = this.parseMetadata(client);

    if (metadata.clientType === ClientTypeEnum.OutgoingMonitoring) {
      const serverId = metadata.socketId.split(':')[1];

      this.outgoingsMonitoringsSockets.delete(serverId);

      await this.cacheManager.del(serverId);

      this.webSocketServer
        .to(MonitoringRooms.AcceptingMonitorings)
        .emit(MonitoringEmits.OutgoingMonitoringDisabled, serverId);
    }

    return client.disconnect(true);
  }

  onModuleDestroy(): any {
    this.webSocketServer.disconnectSockets(true);
  }

  @UseGuards(WsPermissionGuard([Permission.ServersMonitoringsApi]))
  @SubscribeMessage(MonitoringMessagesEnum.SendMonitoringInfo)
  async sendMonitoringInfo(
    @MessageBody() sendMonitoringInfoDto: SendMonitoringInfoDto,
  ): Promise<void> {
    await this.cacheManager.set(
      sendMonitoringInfoDto.serverId,
      sendMonitoringInfoDto,
    );

    this.webSocketServer
      .to(MonitoringRooms.AcceptingMonitorings)
      .emit(MonitoringEmits.ReceivingMonitoringInfo, [sendMonitoringInfoDto]);
  }
}
