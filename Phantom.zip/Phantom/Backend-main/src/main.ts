import { NestFactory, Reflector } from '@nestjs/core';
import { ClassSerializerInterceptor } from '@nestjs/common';
import cookieParser from 'cookie-parser';
import { NestExpressApplication } from '@nestjs/platform-express';
import { envConfig } from '@common/configs/env.config';
import { ApiExceptionHandler } from '@common/api-exceptions/api-exception.handler';
import { CustomValidationPipe } from '@common/pipes/validation-pipe';
import { setupSwagger } from '@common/other/setup-swagger';
import { AppModule } from '@/core/app.module';

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  app.useGlobalInterceptors(new ClassSerializerInterceptor(app.get(Reflector)));
  app.useGlobalFilters(new ApiExceptionHandler());
  app.useGlobalPipes(CustomValidationPipe);
  app.use(cookieParser(envConfig.secure.cookies.secret));
  app.enableCors({
    credentials: true,
    origin: true,
  });
  app.enableShutdownHooks();
  app.enable('trust proxy');

  setupSwagger({
    app: app,
    path: envConfig.swagger.path.pathname,
    enabled: envConfig.swagger.enabled,
  });

  await app.listen(envConfig.api.port);
}

void bootstrap();
