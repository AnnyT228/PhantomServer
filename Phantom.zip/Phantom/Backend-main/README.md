## Description


## First start

```bash
$ yarn run boot
```

## Then

```bash
$ yarn run start:prod
```

## Application launch modes

```bash
# development
$ yarn run start

# watch mode
$ yarn run start:dev

# production mode
$ yarn run start:prod
```
